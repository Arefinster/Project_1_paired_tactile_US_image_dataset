import keras
import numpy as np
from tensorflow.keras.models import load_model
import module_Preprocess
from sklearn.metrics import confusion_matrix
import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

class StructVcenter:
    pass

# Prediction by only TC
def pred_by_tc(file_name, tc_signals):
    # Import the trained model
    modelTC = load_model(file_name)
    #modelTC.summary()

    # Inference
    tc_signals_mat = np.array(tc_signals)
    t_rows, t_cols = tc_signals_mat.shape
    tmrCountTC = 0
    ntmrCountTC = 0
    for t in range(t_rows):
        t_sig = tc_signals_mat[t, :]
        #t_sig = tf.expand_dims(t_sig, axis=-1)
        sig_length = len(t_sig)
        pred_prob_tc = modelTC.predict(t_sig.reshape(1, sig_length, 1))  # Label probability
        pred_prob_tc = np.array(pred_prob_tc)
        pred_prob_tc = np.rint(pred_prob_tc)

        if pred_prob_tc[0,0] == 0 and pred_prob_tc[0,1] == 1:
            tmrCountTC = tmrCountTC + 1
        elif pred_prob_tc[0,0] == 1 and pred_prob_tc[0,1] == 0:
            ntmrCountTC = ntmrCountTC + 1

    # Prediction by only TC
    print("tmrCountTC: ", tmrCountTC)
    print("ntmrCountTC: ", ntmrCountTC)

    if tmrCountTC > ntmrCountTC:
        lbl_onlyTC = "tumor"
    else:
        lbl_onlyTC = "nontumor"

    return lbl_onlyTC

def pred_by_tcusFusion(model_file_name, TC_layer, US_layer, tc_Pairedwt_vMargin_Ftr, fs):
    #TC_layer = np.asarray(TC_layer, dtype=np.float32)
    # First Import the trained model
    modelFSN = load_model(model_file_name)
    #modelFSN.summary()
    
    vCenter = StructVcenter()
    vCenterList = []
    hCenterList = []
    vMargins_unq= []
    conf_hMargins = []
    conf_tcus_pairs = []
    tc_vMargins = []
    num_TC_sigs = len(tc_Pairedwt_vMargin_Ftr)
    if num_TC_sigs == 0:
        lbl_TCUSfsn = "nontumor"
        print('Gone through fusion filter')
    else:
        # Retrieve US Signal Vmargins
        total_vMargins = len(tc_Pairedwt_vMargin_Ftr)
        vMargins = []  # #]', [tc_Pairedwt_vMargin_Ftr[:]]']
        for v in range(total_vMargins):
            vMargins.append([tc_Pairedwt_vMargin_Ftr[v].usVmarginStr, tc_Pairedwt_vMargin_Ftr[v].usVmarginEnd])
        vMargins = np.asarray(vMargins, dtype=np.intc)
        vMargins_unq = module_Preprocess.obtainUnqMargins(vMargins)
        vMargins_unq = np.asarray(vMargins_unq)

        # Retrieve TC signals and put them in a matrix of all signals
        allSigs = []
        e_tcSigLines = []
        vm_r = len(vMargins_unq)
        for v in range(vm_r):
            # Retrieve US signals and put them in the matrix of all signsls
            vrngst = vMargins_unq[v][0] # vertical range start
            vrngen = vMargins_unq[v][1] # vertical range end
            for uu in range(vrngst, vrngen):
                allSigs.append(US_layer[uu, :])
            # Now acquire the mid point between the vertical start and end margins
            mid = round(vrngst + (vrngen - vrngst) / 2)
            vCenter = mid
            vCenterList.append(vCenter)

            # Retrieve TC signals and put them in a matrix of all signals
            for tt in range(num_TC_sigs):
                e_vrngst = tc_Pairedwt_vMargin_Ftr[tt].usVmarginStr
                e_vrngen = tc_Pairedwt_vMargin_Ftr[tt].usVmarginEnd
                overlap = max(0, min(vrngen, e_vrngen) - max(vrngst, e_vrngst))
                if overlap > 0:
                    tcSigIdx = tc_Pairedwt_vMargin_Ftr[tt].minedTCline
                    e_tcSigLines.append(tcSigIdx)
                    allSigs.append(TC_layer[tcSigIdx,:])

        """            
            #for tt in range(num_TC_sigs):
            #    allSigs.append(TC_layer[tc_Pairedwt_vMargin_Ftr[tt].minedTCline, :])
            #vMargins_unq = module_Preprocess.findIntersection(vMargins, len(vMargins))
            # Retrieve US signals and put them in the matrix of all signsls        
            vm_r = len(vMargins_unq)
            for v in range(vm_r):
            vrngst = vMargins_unq[v, 0] # vertical range start
            vrngen = vMargins_unq[v, 1] # vertical range end
            mid = round(vrngst + (vrngen-vrngst)/2)
            vCenter = mid
            vCenterList.append(vCenter)
            for uu in range(vrngst, vrngen):
                allSigs.append(US_layer[uu,:])
        """
        # Inference
        allSigs = np.asarray(allSigs, dtype=np.float32)
        tmrCount_fsn = 0
        ntmrCount_fsn = 0
        rALL = len(allSigs)
        for s in range(rALL):
            sig = allSigs[s, :]
            sig_length = len(sig)
            pred_prob_fsn = modelFSN.predict(sig.reshape(1, sig_length, 1))  # Label probability
            pred_prob_fsn = np.array(pred_prob_fsn)
            pred_prob_fsn = np.rint(pred_prob_fsn)
            if pred_prob_fsn[0, 0] == 0 and pred_prob_fsn[0, 1] == 1:
                tmrCount_fsn = tmrCount_fsn + 1
            elif pred_prob_fsn[0, 0] == 1 and pred_prob_fsn[0, 1] == 0:
                ntmrCount_fsn = ntmrCount_fsn + 1

        # Prediction by fusion
        print("tmrCountFSN: ", tmrCount_fsn)
        print("ntmrCountFSN: ", ntmrCount_fsn)
        if tmrCount_fsn > ntmrCount_fsn:
            grouped_tcus_cmb_hmargins, tc_vMargins, verified_label = module_Preprocess.computeHmargins(e_tcSigLines, vMargins_unq, TC_layer, US_layer, fs)
            ## Verification check --------------------------------------------------------
            if verified_label == "nontumor":
                lbl_TCUSfsn = "nontumor"
                return lbl_TCUSfsn, vMargins_unq, vCenterList, conf_hMargins, hCenterList, conf_tcus_pairs, tc_vMargins
            ## ---------------------------------------------------------------------------
            conf_hMargins, conf_tcus_pairs, verified_label2 = module_Preprocess.finalFeatureTest(grouped_tcus_cmb_hmargins, tc_vMargins, vMargins_unq, TC_layer, US_layer, fs)
            if verified_label2 == "nontumor":
                lbl_TCUSfsn = "nontumor"
                return lbl_TCUSfsn, vMargins_unq, vCenterList, conf_hMargins, hCenterList, conf_tcus_pairs, tc_vMargins
            lbl_TCUSfsn = "tumor"
            # Shape correction of conf_hMargins
            #for s in range(len(conf_hMargins)):
            #    conf_hMargins[s] = conf_hMargins[s].reshape(1,2)
            # Obtain the horizontal centers
            conf_hMargins = (np.asarray(conf_hMargins)).reshape(-1, 2)  # reshape by figuring out the row, and 2 columns
            conf_tcus_pairs = (np.asarray(conf_tcus_pairs)).reshape(-1, 2)
            h_r = len(conf_hMargins)
            for h in range(h_r):
                hrngst = conf_hMargins[h][0]  # horz range start
                hrngen = conf_hMargins[h][1]  # horz range end
                midH = round(hrngst + (hrngen - hrngst) / 2)
                hCenterList.append(midH)
        else:
            lbl_TCUSfsn = "nontumor"
    return lbl_TCUSfsn, vMargins_unq, vCenterList, conf_hMargins, hCenterList, conf_tcus_pairs, tc_vMargins