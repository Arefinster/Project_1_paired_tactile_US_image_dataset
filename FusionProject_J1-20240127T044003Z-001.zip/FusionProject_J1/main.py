import os
import fnmatch
import tkinter
import cv2 as cv
from scipy import signal
from tkinter import filedialog
import matplotlib.pyplot as plt
import scipy.ndimage as ndimage
import module_Preprocess
import module_Signal_Layers
import module_Predictions as mp
from module_Preprocess import us_img_truncLine


root = tkinter.Tk()
root.withdraw()  # use to hide tkinter window

# Select a directory path
currdir = os.getcwd()
folder_path = filedialog.askdirectory(parent=root, initialdir=currdir, title='Please select a directory')
print("Current directory: %s" % folder_path)

# Get a list of TC img and US img file names in the selected directory
tc_fileNames = []
us_fileNames = []
for filename in os.listdir(folder_path):
    if fnmatch.fnmatch(filename, '* TC img.jpg'):
        tc_fileNames.append(filename)
    if fnmatch.fnmatch(filename, '* US img.jpg'):
        us_fileNames.append(filename)

num_elem_tc = len(tc_fileNames)
num_elem_us = len(us_fileNames)
rows = 2
columns = 1

# Define a butterworth filter
fc = 35
fs = 500
n = 2
b, a = signal.butter(n, fc / (fs / 2), 'low')

if num_elem_tc == num_elem_us:
    for n in range(num_elem_tc):
        # Img file names
        curr_tcFile = tc_fileNames[n]
        curr_usFile = us_fileNames[n]
        # Read img files

        tc_img = cv.imread(folder_path + '/' + curr_tcFile)
        us_img = cv.imread(folder_path + '/' + curr_usFile)
        # convert to gray scale
        tc_img = cv.cvtColor(tc_img, cv.COLOR_BGR2GRAY)
        us_img = cv.cvtColor(us_img, cv.COLOR_BGR2GRAY)
        # Display the images aligned
        fig = plt.figure(figsize=(10, 7))
        # Display the TC img
        fig.add_subplot(rows, columns, 1)
        plt.imshow(ndimage.rotate(tc_img, 90, reshape=True))
        plt.axis('on')
        plt.title("TC img")
        # Display the US img
        fig.add_subplot(rows, columns, 2)
        plt.imshow(us_img)
        plt.axis('on')
        plt.title("US img")
        plt.show()

        # Image Preprocess module
        leftRow, rightRow = us_img_truncLine(us_img)
        if leftRow > rightRow:
            startRow = leftRow
        else:
            startRow = rightRow

        tc_img_mat, us_img_mat, t_rows, t_cols, u_rows, u_cols = module_Preprocess.normalize_images(tc_img, us_img)

        # Signal layers module
        tc_layer, rowsTC = module_Signal_Layers.obtain_tc_layer(tc_img_mat, b, a)
        us_layer = module_Signal_Layers.obtain_us_layer(us_img_mat, startRow, t_rows, b, a)
        corr_layer = module_Signal_Layers.obtainCorrLayer(tc_layer, us_layer, startRow)
        tc_Pairedwt_vMargin_Ftr = module_Signal_Layers.entropyLayer(corr_layer, startRow)

        # Prediction by only TC signal using 1D-CNN model
        modelfileTC_1dcnn = "C:/My_Research/May experiments - LIVER models/May Liver Exp 1 Data/TC_US_signal_dataset/best_model_onlyTC_1dcnn_v2.h5"
        label_by_tc_1dcnn = mp.pred_by_tc(modelfileTC_1dcnn, tc_layer)

        # Prediction by only US signal

        # Prediction by only TC signal using transformer model
        modelfileTC_trfrm = "C:/My_Research/May experiments - LIVER models/May Liver Exp 1 Data/TC_US_signal_dataset/best_model_onlyTC_transformer_v2.h5"
        label_by_tc_trfrm = mp.pred_by_tc(modelfileTC_trfrm, tc_layer)

        plt.close()




