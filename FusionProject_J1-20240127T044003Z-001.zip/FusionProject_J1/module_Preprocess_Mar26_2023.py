import numpy as np
import cv2 as cv
import math
import scipy.ndimage as ndimage
import matplotlib.patches as mpatches
import warnings
from statistics import mode
#import statistics
#import scipy as sp
from copy import copy
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.gridspec import GridSpec
import pywt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score #, silhouette_samples

warnings.filterwarnings("ignore")

def createMarginedImageLayer(imgSize, margin, marginDir):
    # imgSize[1] is the height in rows, imgSize[0] is the width in cols
    blank_image = np.zeros((imgSize[1], imgSize[0], 3), dtype = np.uint8)
    if marginDir == 'col':
        blank_image[:, margin[0]:margin[1],:] = (255, 255, 10)  # (B, G, R)
    elif marginDir == 'row':
        blank_image[margin[0]:margin[1],:, :] = (255, 0, 0)  # (B, G, R)
    return blank_image

# Define function for calculating the truncLine
def us_img_truncLine(us_img):
    us_img_mat = np.array(us_img)
    u_rows, u_cols = us_img_mat.shape
    # left index
    for i in range(4,u_rows,1):
        j = 3
        test =us_img[i, j]
        if us_img[i, j] > 5:
            leftRow = i;
            break

    # right index
    for i in range(4, u_rows - 4, 1):
        j = u_cols - 3
        if us_img[i, j] > 5:
            rightRow = i
            break

    return leftRow, rightRow

# Read in the tc img, covert to double, obtain max and min intensity values
def normalize_images(tc_img, us_img):
    # covert TC img from uint8 to double, obtain max and min intensity values# Create tc img matrix
    tc_img = tc_img / 255  # this will be in float64
    tc_img = np.float32(tc_img)
    tc_img_mat = np.array(tc_img)
    max_tc_val = np.max(tc_img_mat)  # find the max and min
    min_tc_val = np.min(tc_img_mat)
    t_rows, t_cols = tc_img_mat.shape
    # Create us img matrix
    us_img = us_img / 255  # this will be in float64
    us_img = np.float32(us_img)
    us_img_mat = np.array(us_img)
    max_us_val = np.max(us_img_mat)  # find the max and min
    min_us_val = np.min(us_img_mat)
    u_rows, u_cols = us_img_mat.shape
    return tc_img_mat, us_img_mat, t_rows, t_cols, u_rows, u_cols

# Normalize a given array between a target range
def scaleArrayValue(inputArray, targetMaxIntensity, targetMinIntensity):
    L_arr = len(inputArray)
    outputArray = np.zeros((L_arr,),dtype=np.float32)
    currentMaxIntensity = np.max(inputArray)
    currentMinIntensity = np.min(inputArray)
    for j in range(L_arr):
        outputArray[j] = ((targetMaxIntensity - targetMinIntensity) * ((inputArray[j] - currentMinIntensity) / (currentMaxIntensity - currentMinIntensity))) + targetMinIntensity
    return outputArray

# Normalize a given matrix
def normalizeDataLayer(data, targetMaxIntensity, targetMinIntensity):
    data = np.asarray(data, dtype=np.float32)
    rows, cols = data.shape
    normalizedDataLayer = np.zeros((rows, cols), dtype=np.float32)
    for i in range(rows):
        normalizedDataLayer[i, :] = scaleArrayValue(data[i,:], targetMaxIntensity, targetMinIntensity)
    return normalizedDataLayer

"""
def RangeIntersection(varargin):
    nset = len(varargin)/2
    if nset == 0:
        l = []
        r = []
    elif nset == 1:
        l, r = MergeBrackets(varargin[:,1], varargin[:,2])
    else:
        [l, r] = deal(varargin{1: 2});
        for k in range(1, nset, 1):
            l, r = RI2(l, r, varargin{2 * k + (-1:0)})


def RI2(l1, r1, l2, r2):
    l = np.maximum(l1, l2)
    r = np.minimum(r1, r2)
    intersect = l < r
    [l, r] = MergeBrackets(l(intersect)', r(intersect)')


def MergeBrackets(left, right):
    notempty = np.where(right >= left)
    left, iorder = np.sort(left[notempty])
    right = right[notempty[iorder]]
    # Allocate, as we don't know yet the size, we assume the largest case
    lower = np.zeros((len(left), 1), float)
    upper = np.zeros((len(right), 1), float)
    # Nothing to do
    if len(lower) == 0:
        return

    # Initialize
    l = left[1]
    u = right[1]
    k = 0

    # Loop on brakets
    for i in range(len(left)):
        if left[i] > u: # new Jk detected
            # Stack the old one
            k = k + 1
            lower[k] = l
            upper[k] = u
            # Reset l and u
            l = left[i]
            u = right[i]
        else:
            u = max(u, right[i])

    # Stack the last one
    k = k + 1
    lower[k] = l
    upper[k] = u
    # Remove the tails
    lower(k + 1: end) = []
    upper(k + 1: end) = []
"""

# Function to print the intersection
def findIntersection(intervals):
    listLength  = len(intervals)
    intervals = np.asarray(intervals)
    if listLength > 1:
        ROWs, COLs = intervals.shape
        # First interval
        l = intervals[0][0]
        r = intervals[0][1]
        # Check rest of the intervals and find the intersection
        for i in range(1, ROWs):
            # If no intersection exists
            if (intervals[i][0] > r or intervals[i][1] < l):
                continue
            # Else update the intersection
            else:
                l = max(l, intervals[i][0])
                r = min(r, intervals[i][1])
        intersectedInterval = [[l, r]]
    elif listLength == 1:
        intersectedInterval = intervals
    intersectedInterval = np.asarray(intersectedInterval)
    return intersectedInterval

def obtainUnqMargins(margins):
    UnqMargins = []
    rows, cols = np.shape(margins)
    #print(rows, cols)
    for i in range (0, rows-1):
      currMargin = margins[i, :]
      qntofremainMargins = rows - i
      qntofMarginsChecked = 0
      intersectingMargins = []
      # first check if the current margin is already in the unqMargins
      if UnqMargins:
        #print(UnqMargins)
        unRows, unCols = np.shape(UnqMargins)
        #UnqMargins.si
        marginPresent = False
        for u in range (0, unRows):
          unqMargin = UnqMargins[u] #, :]
          unqMargin = np.asarray(unqMargin)
          overlap = max(0, min(currMargin[1], unqMargin[1]) - max(currMargin[0], unqMargin[0]))
          if overlap > 0:
            marginPresent = True
            break
        if marginPresent == True:
          continue
      # Check the remaining margins
      for j in range (i+1, rows):
        nextMargin = margins[j, :]
        if nextMargin[0] > currMargin[1] or nextMargin[1] < currMargin[0]:
          qntofMarginsChecked = qntofMarginsChecked + 1
        else:
          intersectingMargins.append(nextMargin) # = [intersectingMargins; nextMargin];
      if qntofMarginsChecked == qntofremainMargins:
         UnqMargins.append(currMargin) #= [UnqMargins; currMargin];
      else:
         intersectingMargins = np.asarray(intersectingMargins)
         l = min(intersectingMargins[:,0])
         r = max(intersectingMargins[:,1])
         UnqMargins.append([l,r]) #= [UnqMargins; [l, r]];
    #unqMargins = np.asarray(UnqMargins)
    return UnqMargins

def computeHmargins(extr_tcLines, vMargins, tcLayer, usLayer, fs):
    selectedMargins = [] # Declare the output list
    extr_tcLines = np.asarray(extr_tcLines)
    ## Group all the tc lines
    tcLineGroups_init = []
    ii = 1 # initialize at the 2nd line
    st = extr_tcLines[ii - 1]
    while ii <= len(extr_tcLines)-1:
        if abs(extr_tcLines[ii] - extr_tcLines[ii - 1]) > 1 and ii < len(extr_tcLines)-1:
            tcLineGroups_init.append([st, extr_tcLines[ii - 1]])
            st = extr_tcLines[ii]
        elif abs(extr_tcLines[ii] - extr_tcLines[ii - 1]) > 1 and ii == len(extr_tcLines)-1:
            tcLineGroups_init.append([st, extr_tcLines[ii - 1]])
            tcLineGroups_init.append([extr_tcLines[ii], extr_tcLines[ii]])
        elif abs(extr_tcLines[ii] - extr_tcLines[ii - 1]) <= 1 and ii == len(extr_tcLines)-1:
            tcLineGroups_init.append([st, extr_tcLines[ii]])
        ii = ii + 1
    # Finalize by removing irrelevant ranges in tcLineGroups_init
    tcLineGroups_init = np.asarray(tcLineGroups_init)
    R,C = tcLineGroups_init.shape
    tcLineGroups = []
    for i in range(R):
        if (tcLineGroups_init[i,1]-tcLineGroups_init[i,0]) >= 10: #or (tcLineGroups_init[i,1]-tcLineGroups_init[i,0]) != math.nan:
            tcLineGroups.append(tcLineGroups_init[i,:])
    ## Acquire the stat-based margins of the tc signals
    tcLineGroups = np.asarray(tcLineGroups)
    tgrows,tgcols = tcLineGroups.shape #len(tcLineGroups)
    all_tcHmargins = []
    for q in range(tgrows):
        currTCrange = tcLineGroups[q,:]
        # signal stats
        meantcSignal = np.mean(tcLayer[currTCrange[0]:currTCrange[1], :], axis=0)
        sdtcSignal = np.std(tcLayer[currTCrange[0]:currTCrange[1], :], axis=0)
        #meanPlusSDtcsig = meantcSignal + sdtcSignal # mean signal upper bound
        #meanMinusSDtcsig = meantcSignal - sdtcSignal

        # collective hMargins
        scTmean = applyCWT(meantcSignal, fs)
        tcMean_hMargins = directed_grad_descent_3D(scTmean)
        tcMean_hMargins = np.asarray(tcMean_hMargins).reshape(-1,2)
        hMargins_from_tcMean_sig, cols_tc_mean = tcMean_hMargins.shape
        # Accumulate the mean-based hMargins into all_tcHmargins
        for a in range(hMargins_from_tcMean_sig):
            if (tcMean_hMargins[a, 0] != tcMean_hMargins[a, 1]):
                all_tcHmargins.append(tcMean_hMargins[a, :])
        # Acquire individual tc hMargins
        for t in range(currTCrange[0], currTCrange[1]): # currTCrange(1, 1):currTCrange(1, 2)
            x = tcLayer[t,:]
            scT = applyCWT(x, fs)
            tc_hMargins = directed_grad_descent_3D(scT)
            tc_hMargins = np.asarray(tc_hMargins).reshape(-1, 2)
            hMargins_from_each_tc_sig, cols_tc_sig = tc_hMargins.shape
            #listLength = len(tc_hMargins)
            temptc_hMargins = []
            if hMargins_from_each_tc_sig >= 1: #listLength > 1:
                #tc_hMargins = np.asarray(tc_hMargins)
                #rows, cols = tc_hMargins.shape
                for s in range(hMargins_from_each_tc_sig):
                    if (tc_hMargins[s, 0] != tc_hMargins[s, 1]):
                        temptc_hMargins.append(tc_hMargins[s, :])
            #elif hMargins_from_each_tc_sig == 1:
                #tc_hMargins = np.asarray(tc_hMargins)
            #    if (tc_hMargins[0,0] != tc_hMargins[0,1]):
            #        temptc_hMargins.append([tc_hMargins[0,0], tc_hMargins[0,1]])
            if not temptc_hMargins:
                continue
            #temptc_hMargins = np.asarray(temptc_hMargins)
            #intrsTChMargins = findIntersection(temptc_hMargins)
            temptc_hMargins = np.asarray(tc_hMargins).reshape(-1,2)
            intrsTChMargins = np.asarray([int(np.round(np.mean(temptc_hMargins[:, 0]))), int(np.round(np.mean(temptc_hMargins[:, 1])))]).reshape(-1,2)
            # appened it only if [1] > [0]
            if (intrsTChMargins[0][0] < intrsTChMargins[0][1] and intrsTChMargins[0][1] - intrsTChMargins[0][0] >= 10):
                all_tcHmargins.append(intrsTChMargins[0,:])
            1
    if len(all_tcHmargins) <= 0:
        verified_label = "nontumor"
        return selectedMargins, tcLineGroups, verified_label

    #Group the all_tcHmargins
    all_tcHmargins = np.asarray(all_tcHmargins)
    grouped_tc_hmargins, tc_hmarginCenters = kmeansBasedMarginSeperator(all_tcHmargins)

    # Acquire all the us hMargins
    all_usHmargins = []
    u_rows, u_cols = vMargins.shape
    for u in range(u_rows):
        currVmargin = vMargins[u, :]
        # stats for US signals
        meanUSsignal = np.mean(usLayer[vMargins[u, 0]:vMargins[u, 1], :], axis=0)
        # sdSignal = std(usLayer(vMargins(k, 1):vMargins(k, 2),:));
        # meanPlusSDsig = meanSignal + sdSignal; % mean signal upper bound
        # meanMinusSDsig = meanSignal - sdSignal; % mean signal lower bound
        scUmean = applyCWT(meanUSsignal, fs)
        usMean_hMargins = directed_grad_descent_3D(scUmean)
        usMean_hMargins = np.asarray(usMean_hMargins).reshape(-1, 2)
        hMargins_from_usMean_sig, cols_us_mean = usMean_hMargins.shape
        # Accumulate the mean-based hMargins into all_tcHmargins
        for a in range(hMargins_from_usMean_sig):
            if (usMean_hMargins[a, 0] != usMean_hMargins[a, 1]):
                all_usHmargins.append(usMean_hMargins[a, :])
        for uu in range(vMargins[u, 0], vMargins[u, 1]):
            us = usLayer[uu, :]
            scU = applyCWT(us,fs)
            us_hMargins = directed_grad_descent_3D(scU)
            us_hMargins = np.asarray(us_hMargins).reshape(-1, 2)
            hMargins_from_each_us_sig, cols_us_sig = us_hMargins.shape
            tempus_hMargins = []
            if hMargins_from_each_us_sig >= 1:  #us_hMargins:
                for s in range(hMargins_from_each_us_sig):
                    if (us_hMargins[s, 0] != us_hMargins[s, 1]):
                        tempus_hMargins.append(us_hMargins[s, :])
            if not tempus_hMargins:
                continue
            #intrsushMargins = findIntersection(us_hMargins)
            tempus_hMargins = np.asarray(tempus_hMargins).reshape(-1, 2)
            intrsushMargins = np.asarray([int(np.round(np.mean(tempus_hMargins[:, 0]))), int(np.round(np.mean(tempus_hMargins[:, 1])))]).reshape(-1, 2)
            if (intrsushMargins[0][0] < intrsushMargins[0][1] and intrsushMargins[0][1] - intrsushMargins[0][0] >= 10):
                all_usHmargins.append([intrsushMargins[0][0], intrsushMargins[0][1]])
    if len(all_usHmargins) <= 0:
        verified_label = "nontumor"
        return selectedMargins, tcLineGroups, verified_label

    # Group the all_usHmargins
    all_usHmargins = np.asarray(all_usHmargins)
    grouped_us_hmargins, us_hmarginCenters = kmeansBasedMarginSeperator(all_usHmargins)

    ## Pair tc and us margins by tc hmargin mid-point to us hmargin mid-point minimum distance
    tcm_rows, tcm_cols = all_tcHmargins.shape
    tcusPaired_hMargin = np.zeros((tcm_rows, 4), dtype=np.int)
    tcus_combined_hMargin = [] # means of the paired tc us hmargins
    usm_rows, usm_cols = all_usHmargins.shape

    for i in range(tcm_rows): #= 1: t_rows
        #currTCmid = (all_tcHmargins(i, 3) - all_tcHmargins(i, 2)) / 2 + all_tcHmargins(i, 2);
        currTCmargin = [all_tcHmargins[i][0], all_tcHmargins[i][1]]
        min_mdist = 10000
        for j in range(usm_rows):
            #currUSmid = (all_usHmargins(j, 4) - all_usHmargins(j, 3)) / 2 + all_usHmargins(j, 3);
            currUSmargin = [all_usHmargins[j][0], all_usHmargins[j][1]]
            # mdist computation
            mdist1 = abs(currUSmargin[0] - currTCmargin[0])
            mdist2 = abs(currUSmargin[1] - currTCmargin[1])
            mdist = mdist1 + mdist2
            if mdist < min_mdist:
                min_mdist = mdist
                closestUSmargin = currUSmargin
        # Save the us margin
        closestUSmargin = np.asarray(closestUSmargin)
        tcusPaired_hMargin[i][2] = closestUSmargin[0]
        tcusPaired_hMargin[i][3] = closestUSmargin[1]
        # Save the tc margin
        tcusPaired_hMargin[i][0] = all_tcHmargins[i][0]
        tcusPaired_hMargin[i][1] = all_tcHmargins[i][1]
        if (currTCmargin[0] < currTCmargin[1] and currTCmargin[1]-currTCmargin[0] >= 10) and (closestUSmargin[0] < closestUSmargin[1] and closestUSmargin[1]-closestUSmargin[0]):
            tcus_combined_hMargin.append([round((currTCmargin[0]+closestUSmargin[0])/2), round((currTCmargin[1]+closestUSmargin[1])/2)])
    tcus_combined_hMargin = np.asarray(tcus_combined_hMargin)
    grouped_tcus_cmb_hmargins, tcus_cmb_hmarginCenters = kmeansBasedMarginSeperator(tcus_combined_hMargin)
    """
    # Use kmeans to acquire left and right lims
    leftLims = KMeans(n_clusters=2).fit((tcusPaired_hMargin[:][2]).reshape(-1,1))
    rightLims = KMeans(n_clusters=2).fit((tcusPaired_hMargin[:][3]).reshape(-1,1))

    # Construct testable Hmargins
    testableHmargins = []
    for i in range(len(leftLims.cluster_centers_)):
        currL = round(leftLims.cluster_centers_[i][0])
        for j in range(len(rightLims.cluster_centers_)):
            currR = round(rightLims.cluster_centers_[j][0])
            testableHmargins.append([currL, currR])
    # Verification check
    if len(testableHmargins) <= 0 or len(tcMean_hMargins) <= 0:
        return selectedMargins, tcLineGroups, "nontumor"
    selectedMargins = minimizeMarginToMarginDist(testableHmargins, tcMean_hMargins)
    #hMargins = obtainUnqMargins(selectedMargins)
    """
    return grouped_tcus_cmb_hmargins, tcLineGroups, "tumor" #selectedMargins

# Distance minimization
def minimizeMarginToMarginDist(seekingMarginSet1, targetMarginSet2):
    selectedMargins = []
    seekingMarginSet1 = np.asarray(seekingMarginSet1)
    targetMarginSet2 = np.asarray(targetMarginSet2)

    rows1, cols1 = seekingMarginSet1.shape
    rows2, cols2 = targetMarginSet2.shape

    for i in range(rows1):
        currSeekMargin = seekingMarginSet1[i][:]
        min_mdist = 10000
        for j in range(rows2):
            currTargetMargin = targetMarginSet2[j][:]
            # mdist computation
            mdist1 = abs(currSeekMargin[0] - currTargetMargin[0])
            mdist2 = abs(currSeekMargin[1] - currTargetMargin[1])
            mdist = mdist1 + mdist2
            if mdist < min_mdist:
                min_mdist = mdist
                closestTargetMargin = currTargetMargin
        selectedMargins.append([closestTargetMargin[0], closestTargetMargin[1]])
    selectedMargins = np.asarray(selectedMargins)
    return selectedMargins

# Stat feature alignment algorithm
def finalFeatureTest(grouped_tcus_cmb_hmargins, tc_vMargins, us_vMargins, TC_layer, US_layer, fs):
    # Set up the grouped list of rectified hMargins
    grouped_hMargins = list()
    grouped_tcusPairs = list()
    grouped_confidences = list()
    for j in range(len(grouped_tcus_cmb_hmargins)):
        grouped_hMargins.append(list())
        grouped_tcusPairs.append(list())
        grouped_confidences.append(list())

    final_hMargins = []
    final_tcusPairs = []

    conf_tcus_pairs = []
    conf_hMargins = []
    conf_PrbRanks = []
    tau = 0.70
    minPixWidth = 10
    for m in range(len(grouped_tcus_cmb_hmargins)):
        given_hMargins = np.asarray(grouped_tcus_cmb_hmargins[m])
        nH, nV = given_hMargins.shape
        # Get rid of duplicate hMargins
        unq_hMargins = removeDuplicateMargins(given_hMargins)
        # Obtain valid hmargins.They have to be at least 3.5 mm wide
        common_hMargins = []
        nQ, nW = unq_hMargins.shape
        for h in range(nQ):
            if (unq_hMargins[h, 1] - unq_hMargins[h, 0]) > minPixWidth:
                common_hMargins.append(unq_hMargins[h,:])
        common_hMargins = np.asarray(common_hMargins)
        # limits
        hM_rows, hM_cols = common_hMargins.shape
        tc_vM_rows, tc_vM_cols = tc_vMargins.shape
        us_vM_rows, us_vM_cols = us_vMargins.shape
        tc_rows, tc_cols = TC_layer.shape

        ## Acquire mean signals from the signal batches
        tc_meanSig_list = np.zeros((tc_vM_rows, tc_cols), dtype=float) # tc_meanSig_list = zeros(tc_vM_rows, tc_cols);
        tc_batchSigStd_list = np.zeros((tc_vM_rows, tc_cols), dtype=float) #zeros(tc_vM_rows, tc_cols);
        us_meanSig_list = np.zeros((us_vM_rows, tc_cols), dtype=float) #zeros(us_vM_rows, tc_cols);
        us_batchSigStd_list = np.zeros((us_vM_rows, tc_cols), dtype=float) #zeros(us_vM_rows, tc_cols);

        ## (These are only for references. These will not be used in the algorithm)
        # Acquire the tc mean and std signals
        for tc_vM in range(tc_vM_rows):
            currTCrange = tc_vMargins[tc_vM, :]
            if (currTCrange[1]-currTCrange[0]) > minPixWidth:
                tc_meanSig_list[tc_vM,:] = np.mean(TC_layer[currTCrange[0]:currTCrange[1],:], axis=0)
                tc_batchSigStd_list[tc_vM,:] = np.std(TC_layer[currTCrange[0]:currTCrange[1],:], axis=0)
        # Acquire the us mean signals
        for us_vM in range(us_vM_rows):
            currUSrange = us_vMargins[us_vM, :]
            if (currUSrange[1]-currUSrange[0]):
                us_meanSig_list[us_vM,:] = np.mean(US_layer[currUSrange[0]:currUSrange[1],:], axis = 0)
                us_batchSigStd_list[us_vM,:] = np.std(US_layer[currUSrange[0]:currUSrange[1],:], axis = 0)

        # Declare a temp place holder
        temp_grouped_hMargins = list()
        temp_grouped_tcusPairs = list()
        temp_tcusPair_confidences = list()
        for l in range(hM_rows):
            temp_grouped_hMargins.append(list())
            temp_grouped_tcusPairs.append(list())
            temp_tcusPair_confidences.append(list())

        ## Obtain areas(signal energy) under mean and std signals with hMargins sliding from left right
        ##### for loop through each group
        for cm_hM in range(hM_rows):
            currHmargins = common_hMargins[cm_hM,:]
            m_win_length = currHmargins[1] - currHmargins[0] + 1
            # Compute the start and the end limits for the sliding function
            st_mark = currHmargins[0] - m_win_length # initialize
            if st_mark < 1: # update condition
                st_mark = st_mark + (-1 * st_mark) + 1
            en_mark = currHmargins[1] # initialize
            if en_mark + m_win_length > tc_cols: # update condition
                offset = en_mark + m_win_length - tc_cols
                en_mark = en_mark - offset
            # Slide the hMargin window from left to right
            currHmargin_upds = []
            areasUnderTCmeanSigs = []
            areasUnderUSmeanSigs = []
            areasUnderTCsigsStd = []
            areasUnderUSsigsStd = []
            energy_of_TCsigSet = []
            energy_of_USsigSet = []
            for cm_win in range(st_mark, en_mark+1):
                # Compute the areas under the TCmean curve for each mean signal
                placeHolder_tc = np.zeros(tc_vM_rows, dtype=float)
                placeHolder_tc_set = np.zeros(tc_vM_rows, dtype=float)
                placeHolder_tcStd = np.zeros(tc_vM_rows, dtype=float)
                for tc_vM in range(tc_vM_rows):
                    # Extract the TC signals between the vertical margins
                    tc_sig_set = np.zeros((tc_vMargins[tc_vM, 1] - tc_vMargins[tc_vM, 0] + 1, tc_cols), dtype=float)
                    tc_sig_set[:, cm_win: cm_win + m_win_length] = TC_layer[tc_vMargins[tc_vM, 0]:tc_vMargins[tc_vM, 1]+1, cm_win: cm_win + m_win_length]
                    #tc_sig_set_energy = np.zeros(tc_vMargins[tc_vM, 1] - tc_vMargins[tc_vM, 0] + 1, dtype=float)
                    tc_sig_set_energy = np.sum(np.square(tc_sig_set), axis = 1)
                    curr_tc_set_energy = np.sum(tc_sig_set_energy)
                    placeHolder_tc_set[tc_vM] = curr_tc_set_energy
                    # Area under the curve of mean sig of a batch tc sigs
                    batch_tc_mean_sig = np.mean(tc_sig_set, axis = 0)
                    area_underTCmean = np.sum(np.square(batch_tc_mean_sig)) #batch_tc_mean_sig.^2);
                    placeHolder_tc[tc_vM] = area_underTCmean
                    # std sig of a batch tc sigs
                    batch_tc_sig_Std = np.std(tc_sig_set, axis = 0)
                    area_underTCstd = np.sum(np.square(batch_tc_sig_Std)) #. ^ 2); % (:, cm_win: cm_win+m_win_length));
                    placeHolder_tcStd[tc_vM] = area_underTCstd
                areasUnderTCmeanSigs.append(placeHolder_tc) #= [areasUnderTCmeanSigs; placeHolder_tc];
                areasUnderTCsigsStd.append(placeHolder_tcStd) #= [areasUnderTCsigsStd; placeHolder_tcStd];
                energy_of_TCsigSet.append(placeHolder_tc_set)
                # Compute the areas under the USmean curve for each mean signal
                placeHolder_us = np.zeros(us_vM_rows, dtype=float)
                placeHolder_us_set = np.zeros(us_vM_rows, dtype=float)
                placeHolder_usStd = np.zeros(us_vM_rows, dtype=float)
                for us_vM in range(us_vM_rows):
                    # Extract the US signals between the vertical margins
                    us_sig_set = np.zeros((us_vMargins[us_vM, 1] - us_vMargins[us_vM, 0] + 1, tc_cols), dtype=float)
                    us_sig_set[:, cm_win: cm_win + m_win_length] = US_layer[us_vMargins[us_vM, 0]: us_vMargins[us_vM, 1]+1, cm_win: cm_win + m_win_length]
                    # Area under the curve of mean sig of a batch US sigs
                    batch_us_mean_sig = np.mean(us_sig_set, axis = 0)
                    batch_us_mean_sigF = batch_us_mean_sig # initialize
                    ONES = np.ones(len(batch_us_mean_sigF),dtype=float)
                    temp = np.subtract(ONES, batch_us_mean_sigF)
                    batch_us_mean_sigF[cm_win : cm_win+m_win_length] = temp[cm_win : cm_win+m_win_length] #- batch_us_mean_sigF[cm_win : cm_win+m_win_length]
                    # Energy computation of the individual US signal
                    temp_flipped_us = np.subtract(ONES, us_sig_set)
                    us_sig_set_energy = np.sum(np.square(temp_flipped_us), axis = 1)
                    curr_us_set_energy = np.sum(us_sig_set_energy)
                    placeHolder_us_set[us_vM] = curr_us_set_energy
                    #
                    area_aboveUSmean = np.sum(np.square(batch_us_mean_sigF)) #; % (:, cm_win: cm_win+m_win_length));
                    placeHolder_us[us_vM] = area_aboveUSmean
                    # std sig of a batch us sigs
                    batch_us_sig_Std = np.std(us_sig_set, axis = 0)
                    area_underUSstd = np.sum(np.square(batch_us_sig_Std)) #; % (:, cm_win: cm_win+m_win_length));
                    placeHolder_usStd[us_vM] = area_underUSstd
                areasUnderUSmeanSigs.append(placeHolder_us) #= [areasUnderUSmeanSigs; placeHolder_us];
                areasUnderUSsigsStd.append(placeHolder_usStd) #= [areasUnderUSsigsStd; ];
                energy_of_USsigSet.append(placeHolder_us_set)
                # record hmargins updates
                currHmargin_upds.append([cm_win, cm_win + m_win_length]) # = [currHmargin_upds; ];
            # Convert 'currHmargin_upds' into 2D array
            currHmargin_upds = np.asarray(currHmargin_upds)
            #currHmargin_upds_length = len(currHmargin_upds)
            currHmargin_upds = currHmargin_upds.reshape(-1,2)

            ## Combined signal responses from mean and std
            # Compute combined area under the curve
            allAreasUnderTCUSmeanCurves = np.zeros((en_mark - st_mark + 1, tc_vM_rows * us_vM_rows), dtype=float)
            allAreasUnderTCUSstdCurves = np.zeros((en_mark - st_mark + 1, tc_vM_rows * us_vM_rows), dtype=float)
            allEnergyUnderTCUSsigs = np.zeros((en_mark - st_mark + 1, tc_vM_rows * us_vM_rows), dtype=float)
            col = 0
            tcus_pairs = []
            tcus_pair_toCol = []
            areasUnderTCmeanSigs = np.asarray(areasUnderTCmeanSigs)
            areasUnderTCsigsStd = np.asarray(areasUnderTCsigsStd)
            energy_of_TCsigSet = np.asarray(energy_of_TCsigSet)

            areasUnderUSmeanSigs = np.asarray(areasUnderUSmeanSigs)
            areasUnderUSsigsStd = np.asarray(areasUnderUSsigsStd)
            energy_of_USsigSet = np.asarray(energy_of_USsigSet)
            for i in range(tc_vM_rows):
                for j in range(us_vM_rows):
                    allAreasUnderTCUSmeanCurves[:, col] = areasUnderTCmeanSigs[:, i] + areasUnderUSmeanSigs[:, j]
                    allAreasUnderTCUSstdCurves[:, col] = areasUnderTCsigsStd[:, i] + areasUnderUSsigsStd[:, j]
                    allEnergyUnderTCUSsigs[:, col] = energy_of_TCsigSet[:, i] + energy_of_USsigSet[:, j]
                    tcus_pairs.append([i, j])
                    col = col + 1
                    tcus_pair_toCol.append([i, j, col])
            tcus_pairs = np.asarray(tcus_pairs)
            tcus_pair_toCol = np.asarray(tcus_pair_toCol)
            ## Acquire maximum meansum and minimum stdsum locations and the corresponding hMargins from the TC-US combinations
            idnUpdHmargin_bymean = []
            idnUpdHmargin_bystd = []
            idnUpdHmargin_bySigs = []

            #psbHmargins = []
            #psbtcusPair = []
            #psbPrbRanks = []
            #fusedHmarginPrbRank = np.zeros(tc_vM_rows * us_vM_rows, dtype=float)
            for k in range(tc_vM_rows * us_vM_rows):
                # Obtain the max value down the column k of the combined TCUS signal curves
                maxEnergyValue = np.max(allEnergyUnderTCUSsigs[:, k])
                rSS = np.where(allEnergyUnderTCUSsigs[:, k] == maxEnergyValue) # Obtain the row where the max value is in the column k
                updHmargin_fromSigs = (currHmargin_upds[rSS,:]).reshape(-1)
                idnUpdHmargin_bySigs.append(updHmargin_fromSigs)

                # Obtain the max value down the column k of the combined TCUS mean curves
                maxMeanValue = np.max(allAreasUnderTCUSmeanCurves[:, k])
                rM = np.where(allAreasUnderTCUSmeanCurves[:, k] == maxMeanValue) # Obtain the row where the max value is in the column k
                updHmargin_fromMean = (currHmargin_upds[rM,:]).reshape(-1)
                idnUpdHmargin_bymean.append(updHmargin_fromMean)

                # Obtain the min value down the column k of the combined TCUS std curves
                minStdValue = np.min(allAreasUnderTCUSstdCurves[:, k])
                rS = np.where(allAreasUnderTCUSstdCurves[:, k] == minStdValue)
                updHmargin_fromStd = (currHmargin_upds[rS,:]).reshape(-1)
                idnUpdHmargin_bystd.append(updHmargin_fromStd)
                # Compute probability rank by comparing tcus std-mean -based hmargins
                #overlap_comb = max(0, min(updHmargin_fromMean[1], updHmargin_fromStd[1]) - max(updHmargin_fromMean[0], updHmargin_fromStd[0]))
                #rangeM = updHmargin_fromMean[1] - updHmargin_fromMean[0]
                #rangeS = updHmargin_fromStd[1] - updHmargin_fromStd[0]
                #fusedHmarginPrbRank[k] = max(overlap_comb/rangeM, overlap_comb/rangeS)

                # Obtain probability to the overlap
                #if fusedHmarginPrbRank[k] >= 0.75:
                #    psbHmargins.append([max(updHmargin_fromMean[0], updHmargin_fromStd[0]), min(updHmargin_fromMean[1], updHmargin_fromStd[1])])
                #    psbtcusPair.append(tcus_pairs[k,:])
                #    psbPrbRanks.append(fusedHmarginPrbRank[k])

            # convert list to array
            idnUpdHmargin_bymean   = (np.asarray(idnUpdHmargin_bymean)).reshape(-1, 2) #
            idnUpdHmargin_bystd    = (np.asarray(idnUpdHmargin_bystd)).reshape(-1, 2)
            idnUpdHmargin_bySigs   = (np.asarray(idnUpdHmargin_bySigs)).reshape(-1, 2)

            ## Find potential margins based on minimum area under the mean and std TC signals
            idnUpdHmargin_byTCsigs = []
            ptnHmarginsFromTC_std = np.zeros((tc_vM_rows, 2), dtype=int) # col is 2 because of --> [start end] format
            ptnHmarginsFromTC_mean = np.zeros((tc_vM_rows, 2), dtype=int) # col is 2 because of --> [start end] format
            tcHmarginPrbRank = np.zeros(tc_vM_rows, dtype=float)
            for p in range(tc_vM_rows):
                # Obtain the max value down the column k of the TC signal curves
                maxEtcSigs = np.max(energy_of_TCsigSet[:, p])
                rTC = np.where(energy_of_TCsigSet[:, p] == maxEtcSigs)  # Obtain the row where the max value is in the column k
                updHmargin_fromTCsigs = (currHmargin_upds[rTC, :]).reshape(-1)
                idnUpdHmargin_byTCsigs.append(updHmargin_fromTCsigs)

                # maximum area under mean signal from batch TC
                maxTCmeanArea = np.max(areasUnderTCmeanSigs[:, p])
                r1 = np.where(areasUnderTCmeanSigs[:, p] == maxTCmeanArea)
                ptnHmarginsFromTC_mean[p,:] = currHmargin_upds[r1,:] # assign by tc batch

                # minimum area under std signal from batch TC
                minTCstdArea = np.min(areasUnderTCsigsStd[:, p])
                r = np.where(areasUnderTCsigsStd[:, p] == minTCstdArea)
                ptnHmarginsFromTC_std[p,:] = currHmargin_upds[r,:] # assign by tc batch
                # Compute probability rank by comparing tc std - mean - based hmargins
                #overlap_tc = max(0, min(ptnHmarginsFromTC_mean[p, 1], ptnHmarginsFromTC_std[p, 1]) - max(ptnHmarginsFromTC_mean[p, 0], ptnHmarginsFromTC_std[p, 0]))
                #rangeM = ptnHmarginsFromTC_mean[p, 1] - ptnHmarginsFromTC_mean[p, 0]
                #rangeS = ptnHmarginsFromTC_std[p, 1] - ptnHmarginsFromTC_std[p, 0]
                #tcHmarginPrbRank[p] = max(overlap_tc/rangeM, overlap_tc/rangeS)
            idnUpdHmargin_byTCsigs = (np.asarray(idnUpdHmargin_byTCsigs)).reshape(-1, 2)

            ## Find potential margins based on maximum area under the mean and std US signals
            ptnHmarginsFromUS_mean = np.zeros((us_vM_rows, 2), dtype=int)
            ptnHmarginsFromUS_std = np.zeros((us_vM_rows, 2), dtype=int)
            usHmarginPrbRank = np.zeros(us_vM_rows, dtype=float)
            idnUpdHmargin_byUSsigs = []
            for p in range(us_vM_rows):
                # Obtain the max value down the column k of the US signal curves
                maxEusSigs = np.max(energy_of_USsigSet[:, p])
                rUS = np.where(energy_of_USsigSet[:, p] == maxEusSigs)  # Obtain the row where the max value is in the column k
                updHmargin_fromUSsigs = (currHmargin_upds[rUS, :]).reshape(-1)
                idnUpdHmargin_byUSsigs.append(updHmargin_fromUSsigs)
                # signal from batch US
                maxUSmeanArea = np.max(areasUnderUSmeanSigs[:, p])
                r1 = np.where(areasUnderUSmeanSigs[:, p] == maxUSmeanArea)
                ptnHmarginsFromUS_mean[p, :] = currHmargin_upds[r1, :] # assign by us batch
                # signal from batch US
                minUSstdArea = np.min(areasUnderUSsigsStd[:, p])
                r = np.where(areasUnderUSsigsStd[:, p] == minUSstdArea)
                ptnHmarginsFromUS_std[p, :] = currHmargin_upds[r, :] # assign by us batch
                # Compute probability rank by comparing us std-mean-based hmargins
                #overlap_us = max(0, min(ptnHmarginsFromUS_mean[p, 1], ptnHmarginsFromUS_std[p, 1]) - max(ptnHmarginsFromUS_mean[p, 0], ptnHmarginsFromUS_std[p, 0]))
                #rangeM = ptnHmarginsFromUS_mean[p,1] - ptnHmarginsFromUS_mean[p,0]
                #rangeS = ptnHmarginsFromUS_std[p,1] - ptnHmarginsFromUS_std[p,0]
                #usHmarginPrbRank[p] = max(overlap_us/rangeM, overlap_us/rangeS)
            idnUpdHmargin_byUSsigs = (np.asarray(idnUpdHmargin_byUSsigs)).reshape(-1, 2)

            ## Verify fused signal-based hmargins against single signal-based hmargins (Method-2)
            verified_hMargins, verified_tcusPairs, confidence = fused_to_single_verification(tcus_pair_toCol,
                                                                                             idnUpdHmargin_bySigs,
                                                                                             idnUpdHmargin_bymean,
                                                                                             idnUpdHmargin_bystd,
                                                                                             idnUpdHmargin_byTCsigs,
                                                                                             ptnHmarginsFromTC_mean,
                                                                                             ptnHmarginsFromTC_std,
                                                                                             idnUpdHmargin_byUSsigs,
                                                                                             ptnHmarginsFromUS_mean,
                                                                                             ptnHmarginsFromUS_std)
            ## Rectify the verified hmargins
            verified_hMargins = np.asarray(verified_hMargins).reshape(-1,2)
            verified_tcusPairs= np.asarray(verified_tcusPairs).reshape(-1,2)
            vrRow, vrCol = verified_hMargins.shape
            if vrRow >= 1:
                """
                for v_r in range(vrRow):
                    rectified_grouped_hMargins[m].append(verified_hMargins[v_r,:])
                    filtered_grouped_tcusPair[m].append(verified_tcusPairs[v_r,:])
                    grouped_tcusPair_confidences[m].append(confidence[v_r])
                """
                for v_r in range(vrRow):
                    temp_grouped_hMargins[cm_hM].append(verified_hMargins[v_r, :]) #
                    temp_grouped_tcusPairs[cm_hM].append(verified_tcusPairs[v_r, :]) #[cm_hM]
                    temp_tcusPair_confidences[cm_hM].append(confidence[v_r]) #[cm_hM]
                """
                confidenceA = exhaustive_overlap_check(verified_hMargins)
                if confidenceA > 0.75:
                    rectified_grouped_hMargins[m].append([int(np.round(np.mean(verified_hMargins[:, 0]))), int(np.round(np.mean(verified_hMargins[:, 1])))])
                    filtered_grouped_tcusPair[m].append(verified_tcusPairs)
                else:
                    rectified_grouped_hMargins[m].append(verified_hMargins)
                    filtered_grouped_tcusPair[m].append(verified_tcusPairs)
                """
                """
                ----------------
                targetRange = currHmargins[1] - currHmargins[0]
                leastDifference = 1000
                closestHMargin = [-1, -1]
                selected_tcus_pair = [-1, -1]
                for v_r in range(vrRow):
                    currRange = verified_hMargins[v_r,1] - verified_hMargins[v_r,0]
                    if abs(currRange - targetRange) < leastDifference:
                        leastDifference = abs(currRange - targetRange)
                        closestHMargin = verified_hMargins[v_r,:]
                        selected_tcus_pair = verified_tcusPairs[v_r,:]
                rectified_grouped_hMargins[m].append(closestHMargin)
                filtered_grouped_tcusPair[m].append(selected_tcus_pair)
                """
            #elif vrRow == 1:
            #    rectified_grouped_hMargins[m].append(verified_hMargins[0,:])
            #    filtered_grouped_tcusPair[m].append(verified_tcusPairs[0,:])
            #    grouped_tcusPair_confidences[m].append(confidence[0])
            """
            ## Verify fused signal-based hmargins against single signal-based hmargins
            psbHmargins = np.asarray(psbHmargins).reshape(-1,2) # reshape by figuring out the row, and 2 columns
            psbtcusPair = np.asarray(psbtcusPair).reshape(-1,2)
            psbPrbRanks = np.asarray(psbPrbRanks)
            pR, pC = psbHmargins.shape
            if pR >= 1: # This means there are fused margins
                for p in range(pR):
                    [vTCstdCount, stdTCidx, probTCs] = verificationCounter(psbHmargins[p,:], psbtcusPair[p,:], psbPrbRanks[p], ptnHmarginsFromTC_std)
                    [vTCmeanCount, meanTCidx, probTCm] = verificationCounter(psbHmargins[p,:], psbtcusPair[p,:], psbPrbRanks[p], ptnHmarginsFromTC_mean)
                    [vUSstdCount, stdUSidx, probUSs] = verificationCounter(psbHmargins[p,:], psbtcusPair[p,:], psbPrbRanks[p], ptnHmarginsFromUS_std)
                    [vUSmeanCount, meanUSidx, probUSm] = verificationCounter(psbHmargins[p,:], psbtcusPair[p,:], psbPrbRanks[p], ptnHmarginsFromUS_mean)
                    totalCount = vTCstdCount + vTCmeanCount + vUSstdCount + vUSmeanCount
                    if totalCount/4 > 0.5:
                        conf_tcus_pairs.append(psbtcusPair[p,:])
                        conf_hMargins.append(psbHmargins[p,:])
                        conf_PrbRanks.append(psbPrbRanks[p])
            elif pR < 1:
                # by mean
                mR, mC = idnUpdHmargin_bymean.shape
                for m in range(mR):
                    [vTCmmCount, mmTCidx, probTCmm] = verificationCounter(idnUpdHmargin_bymean[m,:], tcus_pairs[m,:], psbPrbRanks, ptnHmarginsFromTC_mean) # mm: mean - mean
                    [vTCmsCount, msTCidx, probTCms] = verificationCounter(idnUpdHmargin_bymean[m,:], tcus_pairs[m,:], psbPrbRanks, ptnHmarginsFromTC_std) # ms: mean - std
                    [vUSmmCount, mmUSidx, probUSmm] = verificationCounter(idnUpdHmargin_bymean[m,:], tcus_pairs[m,:], psbPrbRanks, ptnHmarginsFromUS_mean) # mm: mean - mean
                    [vUSmsCount, msUSidx, probUSms] = verificationCounter(idnUpdHmargin_bymean[m,:], tcus_pairs[m,:], psbPrbRanks, ptnHmarginsFromUS_std) # ms: mean - std
                    totalCount1 = vTCmmCount + vTCmsCount + vUSmmCount + vUSmsCount
                    if totalCount1/4 > 0.5:
                        conf_tcus_pairs.append(tcus_pairs[m,:])
                        conf_hMargins.append(idnUpdHmargin_bymean[m,:])
                # by std
                sR, sC = idnUpdHmargin_bystd.shape
                for s in range(sR):
                    [vTCsmCount, smTCidx, probTCsm] = verificationCounter(idnUpdHmargin_bystd[s,:], tcus_pairs[s,:], psbPrbRanks, ptnHmarginsFromTC_mean) # sm: std - mean
                    [vTCssCount, ssTCidx, probTCss] = verificationCounter(idnUpdHmargin_bystd[s,:], tcus_pairs[s,:], psbPrbRanks, ptnHmarginsFromTC_std) # ss: std - std
                    [vUSsmCount, smUSidx, probUSsm] = verificationCounter(idnUpdHmargin_bystd[s,:], tcus_pairs[s,:], psbPrbRanks, ptnHmarginsFromUS_mean) # sm: std - mean
                    [vUSssCount, ssUSidx, probUSss] = verificationCounter(idnUpdHmargin_bystd[s,:], tcus_pairs[s,:], psbPrbRanks, ptnHmarginsFromUS_std) # ms: mean - std
                    totalCount2 = vTCsmCount + vTCssCount + vUSsmCount + vUSssCount
                    if totalCount2/4 > 0.5:
                        conf_tcus_pairs.append(tcus_pairs[s,:])
                        conf_hMargins.append(idnUpdHmargin_bystd[s,:])
            """
        # Now compute the means along each column of temp_grouped lists
        vrCols = len(temp_grouped_hMargins[0]) # Obtain how many columns are in the first list
        for c in range(vrCols):
            categorized_hMargins = []
            categorized_tcusPairs = []
            categorized_confidences = []
            for r in range(hM_rows):
                if temp_tcusPair_confidences[r][c] > 0.5:
                    categorized_hMargins.append(temp_grouped_hMargins[r][c])
                    categorized_tcusPairs.append(temp_grouped_tcusPairs[r][c])
                    categorized_confidences.append(temp_tcusPair_confidences[r][c])
            if len(categorized_confidences) == 0:
                continue
            categorized_hMargins = np.asarray(categorized_hMargins).reshape(-1, 2)
            categorized_tcusPairs = np.asarray(categorized_tcusPairs).reshape(-1, 2)
            # Compute means
            categorized_mean_hMargin = np.asarray([int(round(np.mean(categorized_hMargins[:, 0]))), int(round(np.mean(categorized_hMargins[:, 1])))]).reshape(-1, 2)
            categorized_mode_tcusPair = np.asarray([mode(categorized_tcusPairs[:, 0]), mode(categorized_tcusPairs[:, 1])]).reshape(-1, 2)
            categorized_mean_confidence = np.mean(categorized_confidences)
            #
            grouped_hMargins[m].append(categorized_mean_hMargin)
            grouped_tcusPairs[m].append(categorized_mode_tcusPair)
            grouped_confidences[m].append(categorized_mean_confidence)

    # Check the list for empty cells and accumulate the non-empty cells
    nonEmptyCount = 0 # first count how many cells are non-empty
    nonEmpty_index_list = []
    for l in range(len(grouped_tcusPairs)):
        if len(grouped_tcusPairs[l]) > 0:
            nonEmptyCount = nonEmptyCount + 1
            nonEmpty_index_list.append(l)

    # Generate an intermediate place-holder and filtered place-holder
    int_filtered_grouped_hMargins = list()
    int_filtered_grouped_tcusPair = list()
    int_filtered_tcusPair_confidences = list()
    filtered_grouped_hMargins = list()
    filtered_grouped_tcusPair = list()
    filtered_tcusPair_confidences = list()
    for n in range(nonEmptyCount):
        # intermediate list
        int_filtered_grouped_hMargins.append(list())
        int_filtered_grouped_tcusPair.append(list())
        int_filtered_tcusPair_confidences.append(list())
        # filtered list
        filtered_grouped_hMargins.append(list())
        filtered_grouped_tcusPair.append(list())
        filtered_tcusPair_confidences.append(list())

    # FIRST: Transfer the data from grouped_hMargins, grouped_tcusPairs, grouped_confidences to
    # int_rectified_grouped_hMargins, int_filtered_grouped_tcusPair, int_grouped_tcusPair_confidences
    smallestListIdx = -1
    smallestListLength = 1000
    for j in range(nonEmptyCount):
        nonEmpty_index = nonEmpty_index_list[j]
        int_filtered_grouped_hMargins[j] = grouped_hMargins[nonEmpty_index]
        int_filtered_grouped_tcusPair[j] = grouped_tcusPairs[nonEmpty_index]
        int_filtered_tcusPair_confidences[j] = grouped_confidences[nonEmpty_index]
        if len(int_filtered_tcusPair_confidences[j]) < smallestListLength:
            smallestListLength = len(int_filtered_tcusPair_confidences[j])
            smallestListIdx = j

    # SECOND: Find and accumulate common tcusPairs along the int_filtered_grouped_tcusPair
    for i in range(len(int_filtered_grouped_tcusPair[smallestListIdx])):
        currPair = int_filtered_grouped_tcusPair[smallestListIdx][i]
        samePairCount = 0
        tempPair_list = []
        tempHmargin_list = []
        tempConfidence_list = []
        for k in range(nonEmptyCount):
            for s in range(len(int_filtered_grouped_tcusPair[k])):
                if np.all(currPair == int_filtered_grouped_tcusPair[k][s]):
                    samePairCount = samePairCount + 1
                    tempPair_list.append(int_filtered_grouped_tcusPair[k][s])
                    tempHmargin_list.append(int_filtered_grouped_hMargins[k][s])
                    tempConfidence_list.append(int_filtered_tcusPair_confidences[k][s])
                    break
        if samePairCount == nonEmptyCount:
            for k in range(nonEmptyCount):
                filtered_grouped_hMargins[k].append(tempHmargin_list[k])
                filtered_grouped_tcusPair[k].append(tempPair_list[k])
                filtered_tcusPair_confidences[k].append(tempConfidence_list[k])
    # Gather the hMargins and tcus pairs by the confidences
    vCols = len(filtered_grouped_tcusPair[0])
    if vCols == 1:
        curr_tcus_pairs = []
        curr_hMargins = []
        flag = False
        for rr in range(len(filtered_grouped_tcusPair)):
            if filtered_tcusPair_confidences[rr][0] > 0.5:
                curr_tcus_pairs.append(filtered_grouped_tcusPair[rr][0])
                curr_hMargins.append(filtered_grouped_hMargins[rr][0])
        curr_tcus_pairs = np.array(curr_tcus_pairs).reshape(-1, 2)
        curr_hMargins = np.array(curr_hMargins).reshape(-1, 2)
        mode_tcus_Pair = np.asarray([mode(curr_tcus_pairs[:, 0]), mode(curr_tcus_pairs[:, 1])]).reshape(-1, 2)
        final_hMargins.append([int(np.round(np.mean(curr_hMargins[:, 0]))), int(np.round(np.mean(curr_hMargins[:, 1])))])
        final_tcusPairs.append(mode_tcus_Pair)
    elif vCols > 1:
        for cc in range(vCols):
            curr_tcus_pairs = []
            curr_hMargins = []
            conf_sum = 0
            flag = False
            for rr in range(len(filtered_grouped_tcusPair)):
                if filtered_tcusPair_confidences[rr][cc] > 0.6:  # This will only accumulate those that are greater than tau
                    curr_tcus_pairs.append(filtered_grouped_tcusPair[rr][cc])
                    curr_hMargins.append(filtered_grouped_hMargins[rr][cc])
                    #conf_sum = conf_sum + grouped_tcusPair_confidences[rr][cc]
                else:
                    flag = True
                    break
            if flag == True:
                continue

            curr_tcus_pairs = np.array(curr_tcus_pairs).reshape(-1,2)
            curr_hMargins = np.array(curr_hMargins).reshape(-1,2)

            mode_tcus_Pair = np.asarray([mode(curr_tcus_pairs[:, 0]), mode(curr_tcus_pairs[:, 1])]).reshape(-1, 2)
            #mean_confidence_of_mode_tcusPair = conf_sum/len(grouped_tcusPair_confidences)

            #if mean_confidence_of_mode_tcusPair >= tau:
            final_hMargins.append([int(np.round(np.mean(curr_hMargins[:, 0]))), int(np.round(np.mean(curr_hMargins[:, 1])))])
            final_tcusPairs.append(mode_tcus_Pair)

    if len(final_hMargins) > 0:
        label = "tumor"
    else:
        label = "nontumor"
    #final_hMargins, final_tcusPairs, label = cluster_hMargins_by_tcus_batch_indices(rectified_grouped_hMargins, filtered_grouped_tcusPair)
    """
    # The following is the routine to accumulate the duplicate tc-us paired index 
    # and compute intersection of the corresponding hMargins    
    if not conf_hMargins:
        return conf_hMargins, conf_tcus_pairs, "nontumor"
    conf_tcus_pairs = np.asarray(conf_tcus_pairs)
    conf_hMargins = np.asarray(conf_hMargins)
    cR, cC = conf_tcus_pairs.shape # acquire the total number of tc-us pairs
    if cR == 1: # if there is only one margin available
        return conf_hMargins, conf_tcus_pairs, "tumor"
    visited_array = []
    visited_list = []
    for c in range(cR - 1):
        currPair = conf_tcus_pairs[c,:] # access a paired index
        visited_array = np.asarray(visited_list)
        vR = len(visited_array)  # the curent length of the visited list
        skip = False # initialize as false
        for v in range(vR):  # iterate through all the visited elements
            if np.all(currPair == visited_array[v,:]): # if the current item has been already visited
                skip = True                            # |
                break                                  # |
        if skip == True:                               # V
            continue                                   # skip to the next item
        dupIdx_hmargins = []                           # initialize duplicate indexed hmargins
        dupIdx_hmargins.append(conf_hMargins[c,:])     # start accumulating the corresponding margins
        for e in range(c+1,cR):
            if np.all(currPair == conf_tcus_pairs[e,:]):
                dupIdx_hmargins.append(conf_hMargins[e,:])
        # Compute the intersected margin
        dupIdx_hmargins = np.asarray(dupIdx_hmargins)
        dR, dC = dupIdx_hmargins.shape
        if dR > 1:
            intersectedMargin = findIntersection(dupIdx_hmargins)
            final_hMargins.append(intersectedMargin)
        elif dR == 1:
            final_hMargins.append(dupIdx_hmargins)
        #
        visited_list.append(currPair)
        final_tcusPairs.append(currPair)
    # Check the last element
    rw,cl = conf_tcus_pairs.shape
    lastPair = conf_tcus_pairs[rw-1,:]
    visited_array = np.asarray(visited_list)
    vR, vC = visited_array.shape
    skip = False # initialize as false
    for v in range(vR):  # iterate through all the visited elements
        if np.all(lastPair == visited_array[v,:]): # if the current item has been already visited
            skip = True
            break
    if skip == False:
        final_hMargins.append(conf_hMargins[rw-1,:])
        final_tcusPairs.append(lastPair)
    """
    return final_hMargins, final_tcusPairs, label

def cluster_hMargins_by_tcus_batch_indices(rectified_grouped_hMargins, filtered_grouped_tcusPairs):
    # Declate the list containers for the summarized hMargins and tcusPairs
    collected_hMargins = []
    collected_tcusPairs = []
    confRate_for_tcusPairs = []
    for n in range(len(rectified_grouped_hMargins)): # Access each list in the group
        set_r_hMargins = np.asarray(rectified_grouped_hMargins[n]).reshape(-1,2) # Convert the hMargin list into array
        set_r_tcusPairs = np.asarray(filtered_grouped_tcusPairs[n]).reshape(-1,2) # Convert the tcus pair list into array
        r_rows, r_col = set_r_tcusPairs.shape # Obtain how many items in the current array
        unique_tcusPair_list = [] # Initialize the visited list
        for c in range(r_rows - 1):
            currPair = set_r_tcusPairs[c, :]  # access a paired index
            visited_pairs_array = np.asarray(unique_tcusPair_list)
            vR = len(visited_pairs_array)  # the curent length of the visited list
            skip = False  # initialize as false
            for v in range(vR):  # iterate through all the visited elements
                if np.all(currPair == visited_pairs_array[v, :]):  # if the current item has been already visited
                    skip = True  # |
                    break        # |
            if skip == True:     # V
                continue  # skip to the next item
            grouped_hmargins_by_tcusPairs = []  # initialize grouped_hmargins_by_tcusPairs
            grouped_hmargins_by_tcusPairs.append(set_r_hMargins[c, :])  # start accumulating the corresponding margins
            for e in range(c + 1, r_rows):
                if np.all(currPair == set_r_tcusPairs[e, :]):
                    grouped_hmargins_by_tcusPairs.append(set_r_hMargins[e, :])
            # Compute the mean margin and save
            grouped_hmargins_by_tcusPairs = np.asarray(grouped_hmargins_by_tcusPairs).reshape(-1,2)
            totalItems, cols = grouped_hmargins_by_tcusPairs.shape
            collected_hMargins.append([int(np.round(np.mean(grouped_hmargins_by_tcusPairs[:,0]))), int(np.round(np.mean(grouped_hmargins_by_tcusPairs[:,1])))])
            confRate_for_tcusPairs.append(totalItems/r_rows)
            # update the pair list
            unique_tcusPair_list.append(currPair)
            collected_tcusPairs.append(currPair)
    # Obtain the tcus Pairs and the corresponding hMargins based on confRates (Simple method)
    # *confRate_for_tcusPairs
    acceptedRatio = 0.5
    recollected_tcusPairs = []
    recollected_hMargins = []
    for i in range(len(confRate_for_tcusPairs)):
        if confRate_for_tcusPairs[i] > acceptedRatio:
            recollected_tcusPairs.append(collected_tcusPairs[i])
            recollected_hMargins.append(collected_hMargins[i])
    # The following is the routine to accumulate the duplicate tc-us paired
    # index and compute intersection of the corresponding hMargins
    if not recollected_tcusPairs:
        return recollected_hMargins, recollected_tcusPairs, "nontumor"
    recollected_tcusPairs = np.asarray(recollected_tcusPairs)
    recollected_hMargins = np.asarray(recollected_hMargins)
    cR, cC = recollected_tcusPairs.shape  # acquire the total number of tc-us pairs
    if cR == 1:  # if there is only one margin available
        return recollected_hMargins, recollected_tcusPairs, "tumor"
    final_hMargins = []
    final_tcusPairs = []
    visited_array = []
    visited_list = []
    for c in range(cR - 1):
        currPair = recollected_tcusPairs[c, :]  # access a paired index
        visited_array = np.asarray(visited_list)
        vR = len(visited_array)  # the curent length of the visited list
        skip = False  # initialize as false
        for v in range(vR):  # iterate through all the visited elements
            if np.all(currPair == visited_array[v, :]):  # if the current item has been already visited
                skip = True  # |
                break  # |
        if skip == True:  # V
            continue  # skip to the next item
        dupIdx_hmargins = []  # initialize duplicate indexed hmargins
        dupIdx_hmargins.append(recollected_hMargins[c, :])  # start accumulating the corresponding margins
        for e in range(c + 1, cR):
            if np.all(currPair == recollected_tcusPairs[e, :]):
                dupIdx_hmargins.append(recollected_hMargins[e, :])
        # Compute the intersected margin
        dupIdx_hmargins = np.asarray(dupIdx_hmargins)
        dR, dC = dupIdx_hmargins.shape
        if dR > 1:
            final_hMargins.append([int(np.round(np.mean(dupIdx_hmargins[:, 0]))), int(np.round(np.mean(dupIdx_hmargins[:, 1])))])
        elif dR == 1:
            final_hMargins.append(dupIdx_hmargins)
        # Accumulate
        visited_list.append(currPair)
        final_tcusPairs.append(currPair)
    # Check the last element
    rw, cl = recollected_tcusPairs.shape
    lastPair = recollected_tcusPairs[rw - 1, :]
    visited_array = np.asarray(visited_list)
    vR, vC = visited_array.shape
    skip = False  # initialize as false
    for v in range(vR):  # iterate through all the visited elements
        if np.all(lastPair == visited_array[v, :]):  # if the current item has been already visited
            skip = True
            break
    if skip == False:
        final_hMargins.append(np.asarray(recollected_hMargins[rw - 1, :]).reshape(1,2))
        final_tcusPairs.append(lastPair)
    return final_hMargins, final_tcusPairs, "tumor"

def verificationCounter(targetHmargin, target_tcus_pair, target_prbRank, testableHmargins):
    verificationCount = 0
    idnIdx = -1
    tsR, tsC = testableHmargins.shape
    range1 = targetHmargin[1] - targetHmargin[0]
    max_overlap = 0
    probability = 0
    for q in range(tsR):
        tsMargin = testableHmargins[q, :]
        range2 = tsMargin[1] - tsMargin[0]
        overlap = max(0, min(targetHmargin[1], tsMargin[1]) - max(targetHmargin[0], tsMargin[0]))
        if overlap > max_overlap:
            max_overlap = overlap
            probability = max(max_overlap/range1, max_overlap/range2)
            tempIdx = q
    if probability >= 0.25:
        verificationCount = verificationCount + 1
        idnIdx = tempIdx
    return verificationCount, idnIdx, probability

# Horizontal margin vector
def exhaustive_overlap_check(hm_vector):
    hm_vector = (np.asarray(hm_vector)).reshape(-1,2)
    rows, cols = hm_vector.shape
    # Base condition
    if rows < 1:
        return 0
    tau = 0.60 # tolerance
    acceptedHmargin = 0
    for r in range(rows-1):
        hm1 = hm_vector[r,:]
        range1 = hm1[1]-hm1[0]
        totalComparison = 0
        acceptedOverlap = 0
        for rn in range(r+1, rows):
            hm2 = hm_vector[rn,:]
            range2 = hm1[1] - hm1[0]
            overlap = max(0, min(hm1[1], hm2[1]) - max(hm1[0], hm2[0]))
            overlapRatio = max(overlap/range1, overlap/range2)
            if overlapRatio >= tau:
                acceptedOverlap = acceptedOverlap + 1
            totalComparison = totalComparison+1
        if r < rows-1 and acceptedOverlap/totalComparison >= tau:
            acceptedHmargin = acceptedHmargin + 1
        if r == rows-2 and acceptedOverlap/totalComparison >= tau:
            acceptedHmargin = acceptedHmargin + 1
    return acceptedHmargin/rows

def fused_to_single_verification(tcus_pairs_toCol,
                                 hMargins_byFusedSigs,
                                 hMargins_byFusedMean,
                                 hMargins_byFusedStd,
                                 hMargins_byTCsigs,
                                 hMargins_byTCmean,
                                 hMargins_byTCstd,
                                 hMargins_byUSsigs,
                                 hMargins_byUSmean,
                                 hMargins_byUSstd):
    tau = 0.60
    nCol, fc = tcus_pairs_toCol.shape # hMargins_byFusedSigs.shape
    mCol, sc = hMargins_byTCsigs.shape
    conf_hMargin = []
    conf_tcus_pair = []
    confidence = []
    for n in range(nCol):
        # Obtain the fused signal based margins
        fhm_vector = []
        fhm_vector.append(hMargins_byFusedSigs[n,:])
        fhm_vector.append(hMargins_byFusedMean[n,:])
        fhm_vector.append(hMargins_byFusedStd[n,:])
        # Compute the overlap confidence
        confidenceF = exhaustive_overlap_check(fhm_vector)
        # Acquire the tc and us signal batch pair
        tbatch = tcus_pairs_toCol[n,0]
        ubatch = tcus_pairs_toCol[n,1]
        # Obtain single signal based margins
        shm_vector = []
        #if confidenceF >= tau or confidenceF < tau:
        # Acquire the TC signal-based hmargins from the tc batch
        shm_vector.append(hMargins_byTCsigs[tbatch, :])
        shm_vector.append(hMargins_byTCmean[tbatch, :])
        shm_vector.append(hMargins_byTCstd[tbatch, :])
        # Acquire the US signal-based hmargins from the us batch
        shm_vector.append(hMargins_byUSsigs[ubatch,:])
        shm_vector.append(hMargins_byUSmean[ubatch,:])
        shm_vector.append(hMargins_byUSstd[ubatch,:])
        confidenceS = exhaustive_overlap_check(shm_vector)
        # Combine fused and single hmargins
        hm_vector = fhm_vector + shm_vector
        confidenceC = exhaustive_overlap_check(hm_vector)
        # Compute the combined hmargin and confidence for each batch
        hm_vector = np.asarray(hm_vector)
        conf_hMargin.append([int(round(np.mean(hm_vector[:, 0]))), int(round(np.mean(hm_vector[:, 1])))])
        conf_tcus_pair.append([tbatch, ubatch])
        confidence.append((confidenceF + confidenceS + confidenceC)/3)
        """
            if confidenceS >= tau:
                shm_vector = np.asarray(shm_vector)
                conf_hMargin.append([int(round(np.mean(shm_vector[:, 0]))), int(round(np.mean(shm_vector[:, 1])))])
                conf_tcus_pair.append([tbatch, ubatch])
            elif (confidenceF + confidenceS)/2 > tau:
        #        hm_vector = fhm_vector + shm_vector
                hm_vector = np.asarray(hm_vector)
                conf_hMargin.append([int(round(np.mean(hm_vector[:, 0]))), int(round(np.mean(hm_vector[:, 1])))])
                conf_tcus_pair.append([tbatch, ubatch])
            confidence.append((confidenceF + confidenceS)/2)
        """
    #confidenceA = exhaustive_overlap_check(conf_hMargin)
    return conf_hMargin, conf_tcus_pair, confidence

# Remove duplicate margins
def removeDuplicateMargins(margins):
    margins = np.asarray(margins)
    nH, nV = margins.shape
    final_margins_list = []
    final_margins_array = []
    if nH > 1:
        for h in range(nH):
            temp_margin = margins[h][:]
            # Check the final container
            marginPresent = False
            final_margins_array = np.asarray(final_margins_list)
            fH = len(final_margins_array) #.shape , fV
            for vv in range(fH):
                if np.all(temp_margin == final_margins_array[vv,:]): # temp_margin == final_margins_array[vv,:]:
                    marginPresent = True
                    break
            if marginPresent == False:
                final_margins_list.append(temp_margin) #= [final_margins; temp_margin];
                final_margins_array = np.asarray(final_margins_list)
    elif nH == 1:
        final_margins_array = margins
    return final_margins_array

# Acquire coefficient matrix from continuous wavelet transform
def applyCWT(signal,fs):
    # wavelet parameters
    scales = np.arange(1, 256)
    coefsT, freq = pywt.cwt(signal, scales, 'morl')
    S_T = np.multiply(coefsT, coefsT)
    scT = 100*(np.divide(S_T, np.sum(S_T[:])))
    #scT = 100 * S_T. / sum(S_T(:));
    #freqT = scal2frq(scales, wname, 1 / fs)
    return scT #, freqT

def directed_grad_descent_3D(SC):
    #with warnings.catch_warnings():
    warnings.filterwarnings("ignore")
    HmarginList = []
    maxCap = 0.8
    maximum = np.max(SC) # max(SC[:])
    minimum = np.min(SC)
    x, y = np.where(SC >= maxCap*maximum)
    dataPoints = np.zeros((len(x), 2), dtype=np.int)
    dataPoints[:, 0] = x
    dataPoints[:, 1] = y

    # Now apply k-means to [x, y]
    max_s_score = -100
    opt_k = -1
    for k in range(2, 5):
        cidx = KMeans(n_clusters=k).fit(dataPoints)
        s_score = silhouette_score(dataPoints, cidx.predict(dataPoints))
        if s_score > max_s_score:
            max_s_score = s_score
            opt_k = k
    C = KMeans(n_clusters=opt_k).fit(dataPoints) # Obtain the centroids from the matrix

    totalCentroids, total_col = C.cluster_centers_.shape
    Cc = C.cluster_centers_
    h_dim, w_dim = SC.shape

    # Modify (amplification) function
    sc = SC * 1000
    sc = np.exp(sc)

    #Perform gradient descent on 3D plot
    propagationPoints = []
    alpha = 0.5 # learning rate
    r = 5
    eps = 1
    prev_err = -1
    x_new = -1
    y_new = -1
    for C_in in range(totalCentroids): # this will traverse through each centroid point
        # x, y
        # hd_c = scatter3(round(C(C_in, 2)), round(C(C_in, 1)), SC(round(C(C_in, 1)), round(C(C_in, 2))), 'MarkerEdgeColor', 'k',                'MarkerFaceColor', [1 .1 .0]);
        # hd_c.SizeData = 150;
        endPoints = []
        for theta in range(0, 350, 10):  # this is to traverse through the propagation angles
            alpha = 0.5
            skip = False
            # Old coordinates
            x_old = round(Cc[C_in, 1])
            y_old = round(Cc[C_in, 0])
            # compute the step sizes
            delta_x = r * math.cos(theta*math.pi/180) # -;
            delta_y = r * math.sin(theta*math.pi/180) # -y_old;
            # new coordinates
            x_sft = round(x_old + delta_x)
            y_sft = round(y_old + delta_y)
            # Controlling out of bounds
            if x_sft >= w_dim or y_sft >= h_dim or x_sft <= 0 or y_sft <= 0:
                break
            # Error minimization (optimization loop)
            err = 5
            loopCounter = 0
            cap = 30
            while err > eps:
                # compute gradient
                if delta_x == 0 and delta_y != 0:
                    x_new = x_old
                    y_new = y_old - alpha * ((sc[y_sft, x_old] - sc[y_old, x_old])/delta_y) # forward difference
                elif delta_x != 0 and delta_y == 0:
                    x_new = x_old - alpha * ((sc[y_old, x_sft] - sc[y_old, x_old])/delta_x) # forward difference
                    y_new = y_old
                else:
                    x_new = x_old - alpha * ((sc[y_old, x_sft] - sc[y_old, x_old])/delta_x) # forward difference
                    y_new = y_old - alpha * ((sc[y_sft, x_old] - sc[y_old, x_old])/delta_y) # forward difference
                # obtain the integer value
                x_new = round(x_new)
                y_new = round(y_new)
                if x_new <= 0 or y_new <= 0 or x_new >= w_dim or y_new >= h_dim:
                    alpha = alpha / 2
                    skip = True
                    break
                propagationPoints.append([x_new, y_new]) # = [propagationPoints; [x_new, y_new]];
                #hd2 = scatter3(x_new, y_new, SC(y_new, x_new), 'MarkerEdgeColor', 'k', 'MarkerFaceColor', [.0 .2 .85]);
                #hd2.SizeData = 30;
                # compute error
                err = math.sqrt((x_new - x_old) * (x_new - x_old) + (y_new - y_old) * (y_new - y_old))
                # if the new coordinates are same as old, then break out of the while loop
                if x_new == x_old and y_new == y_old and prev_err == err: # && (x_old + delta_x >= w_dim | | y_old + delta_y >= h_dim)
                    endPoints.append([x_new, y_new]) #= [endPoints;  [x_new, y_new]];
                    break
                prev_err = err
                # update
                x_old = x_new
                y_old = y_new
                x_sft = round(x_old + delta_x)
                y_sft = round(y_old + delta_y)
                if x_sft >= w_dim or y_sft >= h_dim or x_sft <= 0 or y_sft <= 0:
                    break
                loopCounter = loopCounter + 1
                if loopCounter > cap:
                    break
            # End of the while loop
            if skip == True:
                continue
            if x_new > 0 and x_new < w_dim and y_new > 0 and y_new < h_dim:
                endPoints.append([x_new, y_new]) #= [endPoints; [x_new, y_new]];
        # End of the propagation angle
        if endPoints:
            endPoints = np.asarray(endPoints)
            minHmark = min(endPoints[:, 0])
            maxHmark = max(endPoints[:, 1])
            HmarginList.append([minHmark, maxHmark]) #= [HmarginList;        ];
    print('test!')
    1
    # End of the centroid iterator
    return HmarginList

def kmeansBasedMarginSeperator(margins): #, marginCenters):
    # Get rid of duplicate hMargins
    margins = removeDuplicateMargins(margins)
    margins = np.asarray(margins)
    # Compute marginCenters
    H, W = margins.shape
    marginCenters = []
    for v in range(H):
        marginCenters.append(margins[v,0] + round((margins[v,1] - margins[v,0])/2))
    marginCenters = np.asarray(marginCenters)
    marginCenters = marginCenters.reshape(-1, 1)
    mH, mW = marginCenters.shape
    if mH <= 2:
        grouped_margin_table = list()
        for j in range(0, mH):
            grouped_margin_table.append(list())  # different object reference each time
        for j in range(mH):
            grouped_margin_table[j].append(margins[j,:])
        return grouped_margin_table, marginCenters

    # Apply k-means to marginCenters
    max_s_score = -100
    opt_k = -1
    for k in range(2, 5):
        cidx = KMeans(n_clusters=k).fit(marginCenters)
        if k > len(marginCenters) - 1:
            break
        s_score = silhouette_score(marginCenters, cidx.predict(marginCenters))
        if s_score > max_s_score:
            max_s_score = s_score
            opt_k = k
    C = KMeans(n_clusters=opt_k).fit(marginCenters.reshape(-1,1))  # Obtain the centroids from the matrix
    # Generate growing sub-arrays from the label array
    grouped_margin_table = list()
    for i in range(0, opt_k):
        grouped_margin_table.append(list())  # different object reference each time
    for i in range(len(C.labels_)):
        label = C.labels_[i]
        grouped_margin_table[label].append(margins[i])
    return grouped_margin_table, marginCenters

def resultVisualization1(tc_vMargins,
                        us_vMargins,
                        vCenterList, # computed from the us vmargins
                        hCenter_List,
                        conf_hMargins,
                        conf_tcus_pairs,
                        TC_layer,
                        US_layer,
                        tc_img,
                        us_img):
    alpha = 0.80
    # Acquire original image shapes
    tc_rows, tc_cols = tc_img.shape
    us_rows, us_cols = us_img.shape

    # Rotate TC img and convert to 3-channel RGB image (This is for display)
    tc_img_rtt = ndimage.rotate(tc_img, 90, reshape=True)  # rotate the original image
    tc_img_rtt_rgb = cv.cvtColor(tc_img_rtt, cv.COLOR_GRAY2RGB)

    # Obtain a 3-channel RGB image for the US image(This is for display)
    us_img_rgb = cv.cvtColor(us_img, cv.COLOR_GRAY2RGB)

    # Seperate the horizontal margins
    grouped_Hmargins, hCenterList = kmeansBasedMarginSeperator(conf_hMargins) #, hCenterList)
    HH, WW = hCenterList.shape
    # Initialization of the combined US and TC image
    init_hmargin = np.asarray(grouped_Hmargins[0])[0]
    us_Hmargin_img = createMarginedImageLayer([us_cols, us_rows], init_hmargin, 'col')
    us_Hcomb_img = cv.addWeighted(us_img_rgb, 1, us_Hmargin_img, 0, 0)
    tc_Hmargin_img = createMarginedImageLayer([tc_rows, tc_cols], init_hmargin, 'col')
    tc_Hcomb_img = cv.addWeighted(tc_img_rtt_rgb, 1, tc_Hmargin_img, 0, 0)

    # Superimpose and Accumulate all the horizontal margins on the US image
    hmarginsPatches_t = []
    hmarginsPatches_u = []
    for u in range(len(grouped_Hmargins)):
        hmargins_set = np.asarray(grouped_Hmargins[u])
        for v in range(0, len(hmargins_set)):
            single_hmargin = hmargins_set[v]
            # US img
            us_Hmargin_img = createMarginedImageLayer([us_cols, us_rows], single_hmargin, 'col')
            us_Hcomb_img = cv.addWeighted(us_Hcomb_img, alpha, us_Hmargin_img, 1 - alpha, 0)
            # TC img
            tc_Hmargin_img = createMarginedImageLayer([tc_rows, tc_cols], single_hmargin, 'col')
            tc_Hcomb_img = cv.addWeighted(tc_Hcomb_img, alpha, tc_Hmargin_img, 1 - alpha, 0)
            # hMargin patches
            left, bottom, width, height = (single_hmargin[0], 0, (single_hmargin[1]-single_hmargin[0]+1), 1)
            patch_t = mpatches.Rectangle((left, bottom), width, height, alpha=0.25, facecolor="red")
            patch_u = mpatches.Rectangle((left, bottom), width, height, alpha=0.25, facecolor="red")
            hmarginsPatches_t.append(patch_t)
            hmarginsPatches_u.append(patch_u)

    x_axs_len = len(TC_layer[0,:])
    x_values = (np.linspace(0, x_axs_len-1, x_axs_len, dtype=int)).reshape(1, x_axs_len)
    rP, cP = conf_tcus_pairs.shape
    for r in range(rP):
        fig, axs = plt.subplots(4, 1, figsize=(5, 5),  gridspec_kw={'height_ratios': [1, 1, 3.2, 1]}) # layout="constrained",
        # obtain the group index of the TC signals
        tcVrngIdx = conf_tcus_pairs[r, 0]
        # Regarding TC signals
        tc_vMargin = tc_vMargins[tcVrngIdx,:]
        tc_collectiveSig_mean = np.mean(TC_layer[tc_vMargin[0]:tc_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        tc_collectiveSig_std = np.std(TC_layer[tc_vMargin[0]:tc_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        meanPlusSDtcsig = tc_collectiveSig_mean + tc_collectiveSig_std # mean signal upper bound
        meanMinusSDtcsig = tc_collectiveSig_mean - tc_collectiveSig_std
        # plot the tactile image
        tc_margin_img = createMarginedImageLayer([tc_cols, tc_rows], tc_vMargin, 'col')
        tc_margin_img_rtt = ndimage.rotate(tc_margin_img, 90, reshape=True)  # rotate the margin image
        tc_comb_img = cv.addWeighted(tc_Hcomb_img, alpha, tc_margin_img_rtt, 1-alpha, 0)
        rt_tcH, rt_tcW, ch = tc_comb_img.shape
        Extent = 0, rt_tcW-1, 0, rt_tcH-1
        axs[1].imshow(tc_comb_img, origin="upper", extent = Extent, cmap="gray") # '''tc_img_rtt'''origin="upper",
        box1 = axs[1].get_position()
        axs[1].set_position([0.15, box1.y0 + 0.07, box1.width, box1.height])  # (gs[1].get_position())   #
        axs[1].set_ylabel('TC Rows', fontsize = 8, fontname = "Arial")
        axs[1].tick_params(axis='both', which='major', labelsize=8)
        axs[1].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[1].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[1].yaxis.set_major_locator(ticker.MultipleLocator(25))
        axs[1].grid(True)
        # Place the tumor surface centers on the tactile image
        for h in range(HH):#len(hCenterList)):
            axs[1].scatter(hCenterList[h], tc_vMargin[0]+(tc_vMargin[1]-tc_vMargin[0])/2, s=10, c='red', marker='2')
        # Regarding US signals
        usVrngIdx = conf_tcus_pairs[r, 1]  # obtain the group index of the US signals
        us_vMargin = us_vMargins[usVrngIdx,:]
        us_collectiveSig_mean = np.mean(US_layer[us_vMargin[0]:us_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        us_collectiveSig_std = np.std(US_layer[us_vMargin[0]:us_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        meanPlusSDussig = us_collectiveSig_mean + us_collectiveSig_std  # mean signal upper bound
        meanMinusSDussig = us_collectiveSig_mean - us_collectiveSig_std
        # plot the US image
        us_Vmargin_img = createMarginedImageLayer([us_cols, us_rows], us_vMargin, 'row')
        us_comb_img = cv.addWeighted(us_Hcomb_img, alpha, us_Vmargin_img, 1-alpha, 0)
        axs[2].imshow(us_comb_img, cmap="gray")
        box2 = axs[2].get_position()
        axs[2].set_position([0.15, box2.y0 + 0.05, box2.width, box2.height])  # () gs[2].get_position()
        axs[2].set_ylabel('US Rows', fontsize=8, fontname="Arial")
        axs[2].tick_params(axis='both', which='major', labelsize=8)
        axs[2].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[2].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[2].yaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[2].grid(True)
        # Place the tumor centers in the US image
        for h in range(len(hCenterList)):
            axs[2].scatter(hCenterList[h], vCenterList[usVrngIdx], s=10, c='red', marker='2')
        # Plot the tactile signals
        for y_val in range(tc_vMargin[0],tc_vMargin[1]):
            y_values = (TC_layer[y_val,:]).reshape(1, len(TC_layer[y_val,:]))
            axs[0].plot(x_values[0], y_values[0], color='blue', linewidth=0.2, linestyle='-') # TC_layer[tcVrngIdx[0]:tcVrngIdx[1],:])
        axs[0].plot(x_values[0], tc_collectiveSig_mean[0], color='red', linewidth=1.0, linestyle='-')
        axs[0].plot(x_values[0], meanPlusSDtcsig[0], color='green', linewidth=1.0, linestyle='-')
        axs[0].plot(x_values[0], meanMinusSDtcsig[0], color='green', linewidth=1.0, linestyle='-')
        axs[0].set_xlim(0, x_axs_len)
        axs[0].set_ylim(0, 1)
        box0 = axs[0].get_position()
        axs[0].set_position([0.15, box0.y0+0.1, box1.width, box0.height])
        axs[0].tick_params(axis='both', which='major', labelsize=8)
        axs[0].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[0].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))
        axs[0].set_ylabel('TC Intensity', fontsize=8, fontname="Arial")
        axs[0].grid(True)
        for i in range(len(hmarginsPatches_t)):
            newPatch = copy(hmarginsPatches_t[i])
            axs[0].add_patch(newPatch)
        # Plot the US signals
        for y_val in range(us_vMargin[0], us_vMargin[1]):
            y_values = (US_layer[y_val, :]).reshape(1, len(US_layer[y_val, :]))
            axs[3].plot(x_values[0], y_values[0], color='black', linewidth=0.2, linestyle='-')  # US_layer
        axs[3].plot(x_values[0], us_collectiveSig_mean[0], color='red', linewidth=1.0, linestyle='-')
        axs[3].plot(x_values[0], meanPlusSDussig[0], color='green', linewidth=1.0, linestyle='-')
        axs[3].plot(x_values[0], meanMinusSDussig[0], color='green', linewidth=1.0, linestyle='-')
        axs[3].set_xlim(0, x_axs_len)
        axs[3].set_ylim(0, 1)
        box3 = axs[3].get_position()
        axs[3].set_position([0.15, box3.y0+0.03, box1.width, box3.height])
        axs[3].set_xlabel('Aligned image columns', fontsize=8, fontname="Arial")
        axs[3].set_ylabel('US Intensity', fontsize=8, fontname="Arial")
        axs[3].tick_params(axis='both', which='major', labelsize=8)
        axs[3].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[3].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[3].yaxis.set_major_locator(ticker.MultipleLocator(0.2))
        axs[3].grid(True)
        for i in range(len(hmarginsPatches_u)):
            newPatch = copy(hmarginsPatches_u[i])
            axs[3].add_patch(newPatch)
        plt.show()
        r = 1

def resultVisualization2(tc_vMargins,
                        us_vMargins,
                        TC_layer,
                        US_layer,
                        conf_tcus_pairs,
                        tc_img,
                        us_img):
    # Rotate TC img and convert to 3-channel RGB image (This is for display)
    tc_img_rtt = ndimage.rotate(tc_img, 90, reshape=True)  # rotate the original image

    x_axs_len = len(TC_layer[0, :])
    x_values = (np.linspace(0, x_axs_len - 1, x_axs_len, dtype=int)).reshape(1, x_axs_len)
    rP, cP = conf_tcus_pairs.shape
    for r in range(rP):
        fig, axs = plt.subplots(4, 1, figsize=(6, 6),  gridspec_kw={'height_ratios': [1, 1, 3.2, 1]}) # layout="constrained",
        # obtain the group index of the TC signals
        tcVrngIdx = conf_tcus_pairs[r, 0]
        # Regarding TC signals
        tc_vMargin = tc_vMargins[tcVrngIdx,:]
        tc_collectiveSig_mean = np.mean(TC_layer[tc_vMargin[0]:tc_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        tc_collectiveSig_std = np.std(TC_layer[tc_vMargin[0]:tc_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        meanPlusSDtcsig = tc_collectiveSig_mean + tc_collectiveSig_std # mean signal upper bound
        meanMinusSDtcsig = tc_collectiveSig_mean - tc_collectiveSig_std

        rt_tcH, rt_tcW = tc_img_rtt.shape
        Extent = 0, rt_tcW - 1, 0, rt_tcH - 1

        axs[1].imshow(tc_img_rtt, origin="upper", extent=Extent, cmap="gray")  # '''tc_img_rtt'''origin="upper",
        box1 = axs[1].get_position()
        axs[1].set_position([0.15, box1.y0 + 0.07, box1.width, box1.height])  # (gs[1].get_position())   #
        axs[1].set_ylabel('TC Rows', fontsize=8, fontname="Arial")
        axs[1].tick_params(axis='both', which='major', labelsize=8)
        axs[1].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[1].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[1].yaxis.set_major_locator(ticker.MultipleLocator(25))
        axs[1].grid(True)
        # Regarding US signals
        usVrngIdx = conf_tcus_pairs[r, 1]  # obtain the group index of the US signals
        us_vMargin = us_vMargins[usVrngIdx, :]
        us_collectiveSig_mean = np.mean(US_layer[us_vMargin[0]:us_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        us_collectiveSig_std = np.std(US_layer[us_vMargin[0]:us_vMargin[1], :], axis=0).reshape(1, x_axs_len)
        meanPlusSDussig = us_collectiveSig_mean + us_collectiveSig_std  # mean signal upper bound
        meanMinusSDussig = us_collectiveSig_mean - us_collectiveSig_std
        # plot the US image
        axs[2].imshow(us_img, cmap="gray")
        box2 = axs[2].get_position()
        axs[2].set_position([0.15, box2.y0 + 0.05, box2.width, box2.height])  # () gs[2].get_position()
        axs[2].set_ylabel('US Rows', fontsize=8, fontname="Arial")
        axs[2].tick_params(axis='both', which='major', labelsize=8)
        axs[2].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[2].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[2].yaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[2].grid(True)

        # Plot the tactile signals
        for y_val in range(tc_vMargin[0], tc_vMargin[1]):
            y_values = (TC_layer[y_val, :]).reshape(1, len(TC_layer[y_val, :]))
            axs[0].plot(x_values[0], y_values[0], color='blue', linewidth=0.2, linestyle='-')
        axs[0].plot(x_values[0], tc_collectiveSig_mean[0], color='red', linewidth=1.0, linestyle='-')
        axs[0].plot(x_values[0], meanPlusSDtcsig[0], color='green', linewidth=1.0, linestyle='-')
        axs[0].plot(x_values[0], meanMinusSDtcsig[0], color='green', linewidth=1.0, linestyle='-')
        axs[0].set_xlim(0, x_axs_len)
        axs[0].set_ylim(0, 1)
        box0 = axs[0].get_position()
        axs[0].set_position([0.15, box0.y0 + 0.1, box1.width, box0.height])
        axs[0].tick_params(axis='both', which='major', labelsize=8)
        axs[0].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[0].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[0].yaxis.set_major_locator(ticker.MultipleLocator(0.2))
        axs[0].set_ylabel('TC Intensity', fontsize=8, fontname="Arial")
        axs[0].grid(True)

        # Plot the US signals
        for y_val in range(us_vMargin[0], us_vMargin[1]):
            y_values = (US_layer[y_val, :]).reshape(1, len(US_layer[y_val, :]))
            axs[3].plot(x_values[0], y_values[0], color='black', linewidth=0.2, linestyle='-')  # US_layer
        axs[3].plot(x_values[0], us_collectiveSig_mean[0], color='red', linewidth=1.0, linestyle='-')
        axs[3].plot(x_values[0], meanPlusSDussig[0], color='green', linewidth=1.0, linestyle='-')
        axs[3].plot(x_values[0], meanMinusSDussig[0], color='green', linewidth=1.0, linestyle='-')
        axs[3].set_xlim(0, x_axs_len)
        axs[3].set_ylim(0, 1)
        box3 = axs[3].get_position()
        axs[3].set_position([0.15, box3.y0 + 0.03, box1.width, box3.height])
        axs[3].set_xlabel('Aligned image columns', fontsize=8, fontname="Arial")
        axs[3].set_ylabel('US Intensity', fontsize=8, fontname="Arial")
        axs[3].tick_params(axis='both', which='major', labelsize=8)
        axs[3].xaxis.set_major_locator(ticker.MultipleLocator(50))
        axs[3].xaxis.set_minor_locator(ticker.MultipleLocator(10))
        axs[3].yaxis.set_major_locator(ticker.MultipleLocator(0.2))
        axs[3].grid(True)
        plt.show()




