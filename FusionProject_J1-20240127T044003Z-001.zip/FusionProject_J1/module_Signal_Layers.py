import numpy as np
from scipy import signal
#from scipy import linalg
#from scipy.linalg import svd
#from scipy.stats import entropy
#import cv2 as cv
import skimage.util as sku


# define an empty class for margin container
class StructMargin:
    pass


class PairedFeature:
    pass


# Define the TC layer
def obtain_tc_layer(tc_img_mat, b, a):
    tc_layer = []
    rows_tc, cols_tc = tc_img_mat.shape
    for t in range(cols_tc):
        # smoothen the TC signal at first
        x_raw = tc_img_mat[:, t]
        x_raw_filtered = signal.filtfilt(b, a, x_raw)
        if sum(x_raw_filtered) > 0:  # because pre_whiten doesnt work on zero vector
            msg, x = pre_whiten(x_raw_filtered)
            if msg == "NO":
                continue
            else:
                # stack the row vector
                tc_layer.append(x)
        else:
            continue
    return tc_layer, rows_tc


# Define US layer
def obtain_us_layer(us_img_mat, startRow, rowsTC, b, a):
    # Populate the us layer
    rowsUS, colsUS = us_img_mat.shape
    US_layer = np.zeros((rowsUS, rowsTC), float)
    for u in range(startRow, rowsUS, 1):
        y = us_img_mat[u, 0:rowsTC]  # usLine
        if sum(y) > 0:
            # Filter and smooth the US signal
            y_sm = signal.filtfilt(b, a, y)
            # y_sm = y_sm'    # transpose for dimensionality
            [msg2, y_pwh] = pre_whiten(y_sm)  # prewhiten
            if msg2 == "NO":
                continue
            else:
                # stack the row vector
                US_layer[u, 0: rowsTC] = y_pwh
        else:
            continue
    return US_layer


# Define the correlation later
def obtainCorrLayer(tc_layer, us_layer, start_us_row):
    TClayerRows = len(tc_layer)
    USlayerRows, USlayerCols = us_layer.shape
    corr_layer = np.zeros((TClayerRows, USlayerRows), float)
    tt = 0
    for x in tc_layer:
        N = len(x)
        currCorr = np.zeros((1, USlayerRows), float)
        for u in range(start_us_row, USlayerRows, 1):
            y = us_layer[u, :]
            # y = y'
            corr = (1 / N) * np.sum((x - np.mean(x)) * (y - np.mean(y))) / (np.sqrt(np.var(x) * np.var(y)))
            currCorr[0, u] = corr
        corr_layer[tt, :] = currCorr
        tt = tt + 1
    return corr_layer


# Define entropy layer
def entropyLayer(corrLayer, startRow):
    tc_Pairedwt_vMargin_Ftr = []
    crLayerRows, crLayerCols = corrLayer.shape
    minLength = 14  # pix = roughly 2mm

    for c in range(crLayerRows):
        vMargins = entropyAnalysis(corrLayer[c, :], 15)  # function call, returns a list of structs
        margin = StructMargin()
        ftr = PairedFeature()
        for v in vMargins:
            if v.Start < startRow < v.End:
                margin.Start = startRow
                margin.End = v.End
                if (margin.End - margin.Start) >= minLength:
                    # minedTCcols = [minedTCcols; c];
                    # currVmargins = [currVmargins; margin];
                    ftr.usVmarginStr = margin.Start
                    ftr.usVmarginEnd = margin.End
                    ftr.minedTCline = c
                    tc_Pairedwt_vMargin_Ftr.append(ftr)
            if v.Start >= startRow and v.End > startRow:
                if v.End - v.Start >= minLength:
                    ftr.usVmarginStr = v.Start
                    ftr.usVmarginEnd = v.End
                    ftr.minedTCline = c
                    tc_Pairedwt_vMargin_Ftr.append(ftr)
                    # minedTCcols = [minedTCcols; c];
                    # currVmargins = [currVmargins; vMargins(v)];
    return tc_Pairedwt_vMargin_Ftr


# Define entropyAnalysis function
def entropyAnalysis(data, wz):
    sigLength = len(data)
    dataEntropy = -1 * np.ones((sigLength, 1), float)
    margin_list = []
    test = 0
    for i in range(0, sigLength - wz-1, 1):
        # sampledData = zeros(wz, 1);
        if i == 176:
            test = test+1
        sampledData = data[i: (i + (wz - 1))] #, 0]
        sampNormalized = sampledData / np.max(np.abs(sampledData))
        sampNormalized[np.isnan(sampNormalized)] = 0
        dataEntropy[round(wz / 2) + i] = custom_entropy(sampNormalized)
    # Loop for extract zero vectors
    minLength = 14  # pix = roughly 1 mm, changed from 10 pix
    i = 0
    while i < len(dataEntropy):
        margin = StructMargin()
        margin.Start = -1
        margin.End = -1
        if dataEntropy[i, 0] == 0:
            margin.Start = i
            for j in range(margin.Start, len(dataEntropy), 1):
                if dataEntropy[j, 0] != 0:
                    margin.End = j - 1
                    break
            vecLength = margin.End - margin.Start + 1
            if vecLength >= minLength:
                margin_list.append(margin)
            i = margin.End
        i = i + 1

    return margin_list  # , dataEntropy


def custom_entropy(Y):
    """
    Shanon Entropy
    """
    Y = sku.img_as_ubyte(Y)
    unique, count = np.unique(Y, return_counts=True, axis=0)
    prob = np.float32(count/len(Y))
    en = np.sum((-1)*prob*np.log2(prob))
    return en


# Define the prewhiten function
def pre_whiten(X):
    N = X.shape[0]
    P = 1
    if N >= P:
        msg = "YES"
    else:
        msg = "NO"
        Z = -1
        return msg, Z

    # SVD of covariance of X. We could also use svd(X) to proceed but N can be large and so
    # we sacrifice some accuracy for speed.
    cov_x = np.cov(X)
    tol = np.finfo(float).eps
    idx = (cov_x > cov_x * tol)
    if not np.all((idx == 0)):
        msg = "YES"
    else:
        msg = "NO";
        Z = -1
        return msg, Z

    U = 1
    mu = np.mean(X)
    Z = X - mu
    Z = (Z * U) * (1. / np.sqrt(cov_x))
    return msg, Z
